#!/usr/bin/env python3
"""
SCRIPT_NAME:    BEJSON_CMS_PageEditorV2
SCRIPT_VERSION: 18.6
RELATIONAL_ID:  5d9e2f14-8a3b-4c72-9e16-2b4f7c8a1d35
AUTHOR:         Elton Boehnen
DESCRIPTION:    Editor v2 with Stabilized Sidebar, Tasking Workflow, and Gemini Config.
                Unified with CMS Data Model and Storage Format.
CHANGE (2026-11-03): Integrated reusable FileBrowser modal (CMSFilePicker) and AI Context Bubble
architecture into the Tasking Hub (Blog Generator) so selected reference files are injected
before prompts with a strict study/learn/never-copy/never-reference directive.
CHANGE (2026-11-03): Refactored Tasking Hub (Blog Generator) UI to enforce design-html-interfaces
standards: single-row horizontally scrolling workflow toolbar, collapsible part cards with
persistent header badges, copy/select-all buttons on textareas, and word-wrap containment.
CHANGE (2026-10-25): Centralized authentication guard and asset routes via BEJSON_CMS_Shared;
converted storage config BEJSON reads/writes to use field_map cache and atomic_write.
CHANGE (2026-08-06): PKG74 - added an Insert PDF button next to the
existing Media button. Opens its own modal (separate from the Image
picker so PDFs don't clutter/break that grid's thumbnails) fed by the
new /api/media/list_pdf route - lists uploaded PDF MediaAsset rows and
ExternalMedia rows tagged type=pdf, plus a manual URL tab for a one-off
external link. Inserts the same bej-pdf-wrap <object> embed used by
BEJSON_CMS_PageEditor.py's PDF Viewer template, directly at the cursor
in the html_body textarea (existing Image picker's "Copy Tag" flow was
left untouched).
CHANGE (2026-07-07): Added a Media Library picker - this app previously had
no media browsing at all (no ASSETS_DIR, no asset-serving routes). New:
a Media button opens a modal grid gallery of the shared Media Library;
click an image to select it, then Copy Image Tag or Rename (display name
only, physical filename never changes). New routes: /assets/<filename>,
/assets/thumb/<filename>, /api/media/list, /api/media/rename. Verified
with real data via Flask's test client, including a live rename round-trip.
CHANGE (2026-07-07): /api/save unconditionally included item_type and
external_url in every update payload (hardcoded "page"/None) - since
update_record() only touches fields it's given, this silently converted
any external-link page back to a normal page and wiped its URL on every
save through this editor. New pages still default those fields sensibly;
updates now omit them entirely so they're preserved. Verified with a live
round-trip test (external-link page survives a V2 edit intact).
"""

VERSION = 186

from flask import Flask, render_template_string, request, redirect, flash, jsonify, send_file, Response
import os, re, uuid, json, sys, html as _html, io
from pathlib import Path
from datetime import datetime

try:
    import requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    _REQUESTS_AVAILABLE = False
    # api_generate_plan()/api_execute_task() check this flag and return a
    # clean JSON error instead of letting a bare `import requests` inside
    # the function body raise an unhandled ModuleNotFoundError -> 500.

# --- BEJSON Core Pathing ---
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LIB_DIR = os.path.join(PROJECT_ROOT, "src", "lib")
WEB_DIR = os.path.join(PROJECT_ROOT, "src", "web")
if LIB_DIR not in sys.path: sys.path.append(LIB_DIR)
if WEB_DIR not in sys.path: sys.path.append(WEB_DIR)
import lib_bejson_CMS_cms_core as CMSCore
import lib_bejson_CMS_cms_ports as CMSPorts
from lib_bejson_Core_bejson_core import bejson_core_get_field_map, bejson_core_atomic_write
CONFIG_PATH = os.path.join(PROJECT_ROOT, "config.json")
PAGEEDITORV2_PORT = CMSPorts.get_port(CONFIG_PATH, "pageeditorv2_port", "CMS_PAGEEDITORV2_PORT")
ADMIN_PORT = CMSPorts.get_port(CONFIG_PATH, "admin_port", "CMS_ADMIN_PORT")
import lib_cms_persona_writer
from lib_bejson_Core_bejson_env import resolve_path

# --- Config ---
MFDB_DIR = os.path.join(PROJECT_ROOT, "storage", "mfdb")
MANIFEST_PATH = os.path.join(MFDB_DIR, "site_master", "104a.mfdb.bejson")
PAGES_DB_DIR = os.path.join(MFDB_DIR, "pages_db")
ASSETS_DIR = os.path.join(MFDB_DIR, "assets")
THUMBS_DIR = os.path.join(ASSETS_DIR, "_thumbs")
CONTEXT_DIR = os.path.join(PROJECT_ROOT, "Context")
os.makedirs(CONTEXT_DIR, exist_ok=True)

GEMINI_KEYS_PATH = os.path.expanduser("~/.env/gemini_keys.bejson")
MODEL_REGISTRY_PATH = resolve_path("{INTERNAL_STORAGE}/Admin/resources/Schemas/gemini_model_registry.104a.bejson")
STORAGE_CONFIG_PATH = resolve_path("{INTERNAL_STORAGE}/Admin/resources/Flask_Components/Component-File_Selector/config/path_config.104a.bejson")

# =============================================================================
# APP INITIALIZATION
# =============================================================================

app = Flask(__name__)
app.secret_key = os.environ.get('CMS_SECRET_KEY') or os.urandom(24).hex()  # Set CMS_SECRET_KEY env var in production

from BEJSON_CMS_Shared import register_auth_guard, serve_shared_asset, serve_shared_thumb
from BEJSON_CMS_FileBrowser import filebrowser_cube
from lib_bejson_Core_bejson_path_guard import bejson_safe_join

register_auth_guard(app)
app.register_blueprint(filebrowser_cube)


@app.after_request
def add_cors_headers(response):
    response.headers.add("Access-Control-Allow-Origin", "*")
    response.headers.add("Access-Control-Allow-Headers", "Content-Type,Authorization")
    response.headers.add("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS")
    return response

db = CMSCore.CMSCore(MANIFEST_PATH)
writer = lib_cms_persona_writer.PersonaWriter(MANIFEST_PATH)

# =============================================================================
# STORAGE & CONTEXT LOGIC
# =============================================================================

def load_storage_config():
    if not os.path.exists(STORAGE_CONFIG_PATH): return {}
    try:
        with open(STORAGE_CONFIG_PATH, "r") as f: return json.load(f)
    except: return {}

def save_storage_config(storage_config_document):
    os.makedirs(os.path.dirname(STORAGE_CONFIG_PATH), exist_ok=True)
    bejson_core_atomic_write(STORAGE_CONFIG_PATH, storage_config_document)

def _resolve_storage_field_indices(storage_config_document):
    """Resolve label, path, and enabled column indices via BEJSON field_map cache."""
    storage_field_map_cache = bejson_core_get_field_map(storage_config_document) if storage_config_document.get("Fields") else {}
    label_column_index = storage_field_map_cache.get("label", storage_field_map_cache.get("name", 0))
    path_column_index = storage_field_map_cache.get("path", 1)
    enabled_column_index = storage_field_map_cache.get("enabled", 2)
    return label_column_index, path_column_index, enabled_column_index

@app.route("/api/storage/config", methods=["GET", "POST"])
def api_storage_config():
    if request.method == "POST":
        request_storage_payload = request.json
        storage_config_document = load_storage_config()
        label_idx, path_idx, enabled_idx = _resolve_storage_field_indices(storage_config_document)
        updated_storage_rows = []
        for storage_row in storage_config_document.get("Values", []):
            storage_row_label = storage_row[label_idx]
            if storage_row_label in request_storage_payload:
                updated_row = list(storage_row)
                updated_row[path_idx] = request_storage_payload[storage_row_label]["path"]
                updated_row[enabled_idx] = request_storage_payload[storage_row_label]["enabled"]
                updated_storage_rows.append(updated_row)
            else:
                updated_storage_rows.append(storage_row)
        storage_config_document["Values"] = updated_storage_rows
        save_storage_config(storage_config_document)
        return jsonify({"ok": True})
    
    storage_config_document = load_storage_config()
    label_idx, path_idx, enabled_idx = _resolve_storage_field_indices(storage_config_document)
    paths = {
        storage_row[label_idx]: {"path": storage_row[path_idx], "enabled": storage_row[enabled_idx]}
        for storage_row in storage_config_document.get("Values", [])
    }
    return jsonify({"ok": True, "paths": paths})

@app.route("/api/storage/list_files")
def api_list_files():
    storage_config_document = load_storage_config()
    _, path_idx, enabled_idx = _resolve_storage_field_indices(storage_config_document)
    enabled_path = next(
        (storage_row[path_idx] for storage_row in storage_config_document.get("Values", []) if storage_row[enabled_idx]),
        os.path.expanduser("~")
    )
    try:
        files = sorted([f for f in os.listdir(enabled_path) if os.path.isfile(os.path.join(enabled_path, f))])
        return jsonify({"ok": True, "files": files, "path": enabled_path})
    except Exception as e: return jsonify({"ok": False, "error": str(e)})

@app.route("/api/context/list")
def api_list_context():
    files = [f for f in os.listdir(CONTEXT_DIR) if os.path.isfile(os.path.join(CONTEXT_DIR, f))]
    return jsonify({"ok": True, "files": files})

@app.route("/api/context/upload", methods=["POST"])
def api_upload_context():
    try:
        file = request.files.get("file")
        if not file: return jsonify({"ok": False, "error": "No file"})
        file.save(os.path.join(CONTEXT_DIR, file.filename))
        return jsonify({"ok": True, "msg": f"Uploaded {file.filename}"})
    except Exception as e: return jsonify({"ok": False, "error": str(e)})

def get_context_content(filenames):
    storage_config_document = load_storage_config()
    _, path_idx, enabled_idx = _resolve_storage_field_indices(storage_config_document)
    enabled_path = next(
        (storage_row[path_idx] for storage_row in storage_config_document.get("Values", []) if storage_row[enabled_idx]),
        CONTEXT_DIR
    )
    content = ""
    for f in filenames:
        path = os.path.join(enabled_path, f)
        if not os.path.exists(path): path = os.path.join(CONTEXT_DIR, f)
        if os.path.exists(path):
            try:
                with open(path, "r") as f_in: 
                    text = f_in.read()
                    content += f"\n--- REFERENCE FILE: {f} ---\n{text}\n"
            except: pass
    return content

# =============================================================================
# CLI_AI 48 & BKS-1 STANDARDIZED BOOK / BLOG JOB API
# =============================================================================

from lib_bejson_AI_ai_writing import (
    ai_writing_call,
    ai_writing_get_providers_and_models,
    _extract_json_payload,
    _strip_outer_code_fence,
)
from lib_bejson_CMS_bks_blog_jobs import (
    cms_bks_approve_and_overwrite_post,
    cms_bks_bootstrap,
    cms_bks_create_blog_job,
    cms_bks_delete_context_file,
    cms_bks_execute_all_parts,
    cms_bks_execute_part,
    cms_bks_get_context_bubble_state,
    cms_bks_get_job_detail,
    cms_bks_import_context_file,
    cms_bks_import_context_paths,
    cms_bks_list_jobs,
    cms_bks_list_templates,
    cms_bks_merge_parts,
    cms_bks_toggle_context_file,
    cms_bks_update_job_metadata_and_plan,
)

def get_gemini_models():
    info = ai_writing_get_providers_and_models()
    models = info.get("models", [])
    if models:
        return models
    if not os.path.exists(MODEL_REGISTRY_PATH):
        return []
    try:
        with open(MODEL_REGISTRY_PATH, 'r') as f:
            reg = json.load(f)
        fields = [f['name'] for f in reg['Fields']]
        return [dict(zip(fields, row)) for row in reg['Values']]
    except Exception:
        return []

@app.route("/api/ping")
def api_ping():
    return jsonify({"ok": True, "msg": "PONG"})

@app.route('/api/settings/models')
def api_get_models():
    info = ai_writing_get_providers_and_models()
    return jsonify({
        "ok": True,
        "models": info.get("models", []),
        "providers": info.get("providers", []),
        "models_by_provider": info.get("models_by_provider", {}),
    })

@app.route('/api/bks/bootstrap')
def api_bks_bootstrap():
    db.mount()
    pages = db.get_records("PageRecord")
    categories = db.get_records("Category")
    authors = db.get_records("AuthorProfile")
    ai_info = ai_writing_get_providers_and_models()
    return jsonify({
        "ok": True,
        "templates": cms_bks_list_templates(Path(PROJECT_ROOT)),
        "jobs": cms_bks_list_jobs(Path(PROJECT_ROOT)),
        "pages": pages,
        "categories": categories,
        "authors": authors,
        "ai": ai_info,
        "providers": ai_info["providers"],
        "models_by_provider": ai_info["models_by_provider"],
        "models": ai_info["models"],
        "context_bubble": cms_bks_get_context_bubble_state(Path(PROJECT_ROOT)),
    })

@app.route('/api/bks/context_files', methods=['GET', 'POST'])
def api_bks_context_files():
    if request.method == 'GET':
        author = request.args.get("author")
        return jsonify(cms_bks_get_context_bubble_state(Path(PROJECT_ROOT), author=author))
    uploaded_files = request.files.getlist("files")
    if uploaded_files:
        last_res = None
        for fobj in uploaded_files:
            if not fobj or not fobj.filename:
                continue
            raw_bytes = fobj.read()
            last_res = cms_bks_import_context_file(Path(PROJECT_ROOT), fobj.filename, raw_bytes, enabled=True)
        return jsonify(last_res or cms_bks_get_context_bubble_state(Path(PROJECT_ROOT)))
    data = request.get_json(silent=True) or {}
    filename = (data.get("filename") or "").strip()
    content = data.get("content") or ""
    if not filename:
        return jsonify({"ok": False, "error": "filename or uploaded file required"})
    return jsonify(cms_bks_import_context_file(Path(PROJECT_ROOT), filename, content, enabled=True))

@app.route('/api/bks/context_files/import_pick', methods=['POST'])
def api_bks_context_files_import_pick():
    data = request.get_json(silent=True) or {}
    paths = data.get("paths") or []
    if isinstance(paths, str):
        paths = [paths]
    if not paths:
        return jsonify({"ok": False, "error": "paths list is required"})
    return jsonify(cms_bks_import_context_paths(Path(PROJECT_ROOT), paths, enabled=True))

@app.route('/api/bks/context_files/toggle', methods=['POST'])
def api_bks_context_files_toggle():
    data = request.get_json(silent=True) or {}
    filename = (data.get("filename") or "").strip()
    enabled = bool(data.get("enabled", True))
    if not filename:
        return jsonify({"ok": False, "error": "filename required"})
    return jsonify(cms_bks_toggle_context_file(Path(PROJECT_ROOT), filename, enabled))

@app.route('/api/bks/context_files/delete', methods=['POST'])
def api_bks_context_files_delete():
    data = request.get_json(silent=True) or {}
    filename = (data.get("filename") or "").strip()
    if not filename:
        return jsonify({"ok": False, "error": "filename required"})
    return jsonify(cms_bks_delete_context_file(Path(PROJECT_ROOT), filename))

@app.route('/api/bks/job/<job_slug>')
def api_bks_get_job(job_slug):
    detail = cms_bks_get_job_detail(Path(PROJECT_ROOT), job_slug)
    return jsonify(detail)

@app.route('/api/bks/create_plan', methods=['POST'])
def api_bks_create_plan():
    data = request.get_json(silent=True) or {}
    topic = (data.get("topic") or data.get("prompt") or data.get("title") or "").strip()
    if not topic:
        return jsonify({"ok": False, "error": "Topic / prompt is required"})
    title = (data.get("title") or "").strip() or None
    target_page_uuid = (data.get("target_page_uuid") or "").strip() or None
    booktype_slug = (data.get("booktype_slug") or data.get("book_type_id") or "blog_post_4part").strip()
    chapter_count = int(data.get("chapter_count") or 4)
    category = (data.get("category") or data.get("category_name") or "Uncategorized").strip()
    author = (data.get("author") or data.get("author_name") or data.get("profile_name") or "boehnenelton2024").strip()
    page_type = (data.get("page_type") or "blog").strip()
    provider = (data.get("provider") or "geminirest").strip()
    model_id = (data.get("model") or data.get("model_id") or "").strip() or None
    use_ai_plan = data.get("use_ai_plan", True)
    custom_nodes = data.get("custom_nodes")

    persona = writer.get_persona(author) if author else None
    persona_inst = writer.assemble_system_instruction(persona) if persona else None
    ctx_files = data.get("context_files") or []
    ctx_text = get_context_content(ctx_files) if ctx_files else (data.get("context_text") or "")

    try:
        detail = cms_bks_create_blog_job(
            Path(PROJECT_ROOT),
            topic=topic,
            title=title,
            target_page_uuid=target_page_uuid,
            booktype_slug=booktype_slug,
            chapter_count=chapter_count,
            category=category,
            author=author,
            page_type=page_type,
            provider=provider,
            model_id=model_id,
            author_system_instruction=persona_inst,
            context_text=ctx_text,
            use_ai_plan=bool(use_ai_plan),
            custom_nodes=custom_nodes,
        )
        return jsonify(detail)
    except Exception as err:
        return jsonify({"ok": False, "error": str(err)})

@app.route('/api/bks/update_plan', methods=['POST'])
def api_bks_update_plan():
    data = request.get_json(silent=True) or {}
    job_slug = (data.get("job_slug") or "").strip()
    if not job_slug:
        return jsonify({"ok": False, "error": "job_slug is required"})
    detail = cms_bks_update_job_metadata_and_plan(
        Path(PROJECT_ROOT),
        job_slug,
        title=data.get("title"),
        topic=data.get("topic"),
        target_page_uuid=data.get("target_page_uuid"),
        category=data.get("category") or data.get("category_name"),
        author=data.get("author") or data.get("author_name"),
        template_key=data.get("template_key"),
        page_type=data.get("page_type"),
        provider=data.get("provider"),
        model_id=data.get("model_id"),
        parts_updates=data.get("parts"),
    )
    return jsonify(detail)

@app.route('/api/bks/execute_part', methods=['POST'])
def api_bks_execute_part():
    data = request.get_json(silent=True) or {}
    job_slug = (data.get("job_slug") or "").strip()
    if not job_slug:
        return jsonify({"ok": False, "error": "job_slug is required"})
    author = data.get("author") or data.get("author_name") or data.get("profile_name")
    persona = writer.get_persona(author) if author else None
    persona_inst = writer.assemble_system_instruction(persona) if persona else None
    ctx_files = data.get("context_files") or []
    ctx_text = get_context_content(ctx_files) if ctx_files else (data.get("context_text") or "")

    detail = cms_bks_execute_part(
        Path(PROJECT_ROOT),
        job_slug,
        part_index=data.get("part_index"),
        chapter_uuid=data.get("chapter_uuid"),
        provider=data.get("provider"),
        model_id=data.get("model") or data.get("model_id"),
        author_system_instruction=persona_inst,
        extra_context=ctx_text,
        custom_body_md=data.get("custom_body_md"),
        min_words_override=data.get("min_words_override"),
    )
    return jsonify(detail)

@app.route('/api/bks/execute_all', methods=['POST'])
def api_bks_execute_all():
    data = request.get_json(silent=True) or {}
    job_slug = (data.get("job_slug") or "").strip()
    if not job_slug:
        return jsonify({"ok": False, "error": "job_slug is required"})
    author = data.get("author") or data.get("author_name") or data.get("profile_name")
    persona = writer.get_persona(author) if author else None
    persona_inst = writer.assemble_system_instruction(persona) if persona else None
    ctx_files = data.get("context_files") or []
    ctx_text = get_context_content(ctx_files) if ctx_files else (data.get("context_text") or "")

    detail = cms_bks_execute_all_parts(
        Path(PROJECT_ROOT),
        job_slug,
        provider=data.get("provider"),
        model_id=data.get("model") or data.get("model_id"),
        author_system_instruction=persona_inst,
        extra_context=ctx_text,
        force_all=bool(data.get("force_all", False)),
        min_words_override=data.get("min_words_override"),
    )
    return jsonify(detail)

@app.route('/api/bks/merge', methods=['POST'])
def api_bks_merge():
    data = request.get_json(silent=True) or {}
    job_slug = (data.get("job_slug") or "").strip()
    if not job_slug:
        return jsonify({"ok": False, "error": "job_slug is required"})
    res = cms_bks_merge_parts(Path(PROJECT_ROOT), job_slug)
    res["detail"] = cms_bks_get_job_detail(Path(PROJECT_ROOT), job_slug)
    return jsonify(res)

@app.route('/api/bks/approve', methods=['POST'])
def api_bks_approve():
    data = request.get_json(silent=True) or {}
    job_slug = (data.get("job_slug") or "").strip()
    if not job_slug:
        return jsonify({"ok": False, "error": "job_slug is required"})
    res = cms_bks_approve_and_overwrite_post(
        Path(PROJECT_ROOT),
        job_slug,
        target_page_uuid=data.get("target_page_uuid"),
        title_override=data.get("title"),
        category_override=data.get("category") or data.get("category_name"),
        author_override=data.get("author") or data.get("author_name"),
        template_key=data.get("template_key"),
        page_type_override=data.get("page_type"),
        edited_markdown=data.get("edited_markdown") or data.get("merged_md"),
        trigger_publish=bool(data.get("trigger_publish", False)),
    )
    return jsonify(res)

@app.route('/api/tasking/generate_plan', methods=['POST'])
def api_generate_plan():
    data = request.get_json(silent=True) or {}
    prompt = data.get('prompt')
    provider = data.get('provider', 'geminirest')
    model = data.get('model', 'gemini-2.5-flash')
    profile_name = data.get('profile_name')
    if not prompt:
        return jsonify({"ok": False, "error": "Prompt required"})

    # Create a full BKS-1 4-part blog post job & plan backed by CLI_AI 48 ai_dispatch_call
    res = cms_bks_create_blog_job(
        Path(PROJECT_ROOT),
        topic=prompt,
        title=data.get('title'),
        target_page_uuid=data.get('target_page_uuid'),
        booktype_slug=data.get('booktype_slug', 'blog_post_4part'),
        chapter_count=int(data.get('chapter_count', 4)),
        category=data.get('category', 'Uncategorized'),
        author=profile_name or 'boehnenelton2024',
        page_type=data.get('page_type', 'blog'),
        provider=provider,
        model_id=model,
        use_ai_plan=True,
    )
    if not res.get("ok"):
        return jsonify({"ok": False, "error": res.get("error", "Plan generation failed")})
    tasks = [
        {"title": p["title"], "prompt": p["brief"], "chapter_uuid": p["chapter_uuid"]}
        for p in res.get("parts", [])
    ]
    return jsonify({"ok": True, "tasks": tasks, "job": res})

@app.route('/api/tasking/execute_task', methods=['POST'])
def api_execute_task():
    data = request.get_json(silent=True) or {}
    task_title = data.get('title', 'Part')
    task_prompt = data.get('prompt')
    full_plan = data.get('full_plan', [])
    provider = data.get('provider', 'geminirest')
    model = data.get('model', 'gemini-2.5-flash')
    profile_name = data.get('profile_name')
    job_slug = data.get('job_slug')
    chapter_uuid = data.get('chapter_uuid')

    if job_slug:
        res = cms_bks_execute_part(
            Path(PROJECT_ROOT),
            job_slug,
            chapter_uuid=chapter_uuid,
            provider=provider,
            model_id=model,
        )
        if res.get("ok"):
            step = res.get("step_result") or {}
            md_body = step.get("body_md") or ""
            parsed = convert_markdown_to_cms_article(md_body, task_title)
            return jsonify({
                "ok": True,
                "content": parsed["html_body"],
                "markdown": md_body,
                "step_result": step,
                "job": res,
            })
        return jsonify({"ok": False, "error": res.get("error", "Part execution failed")})

    if not task_prompt:
        return jsonify({"ok": False, "error": "Prompt required"})

    plan_context = "\n".join([f"- {t['title']}" for t in full_plan if isinstance(t, dict) and t.get('title')])
    format_inst = f"Document Plan:\n{plan_context}\n\nTask: {task_title}\nOutput ONLY clean HTML body content. No ``` tags."
    resp = writer.dispatch_ai(
        task_prompt,
        provider=provider,
        model=model,
        persona_name=profile_name,
        system_instruction=format_inst,
    )
    if not resp.get("success"):
        return jsonify({"ok": False, "error": resp.get("error", "AI call failed")})
    content = _strip_outer_code_fence(resp.get("content", ""))
    return jsonify({"ok": True, "content": content})

# =============================================================================
# CMS INTEGRATION API
# =============================================================================

from lib_bejson_CMS_md2html import convert_markdown_to_cms_article

def _get_page_content_fields(page_uuid):
    """Read html_body, markdown_body, and source_code from pages_db/<uuid>.json via field_map cache."""
    pfile = os.path.join(PAGES_DB_DIR, f"{page_uuid}.json")
    if not os.path.exists(pfile):
        return "", "", ""
    try:
        with open(pfile, 'r', encoding='utf-8') as f:
            data = json.load(f)
        field_map = bejson_core_get_field_map(data)
        p_idx = field_map.get("Record_Type_Parent", -1)
        hb_idx = field_map.get("html_body", -1)
        mb_idx = field_map.get("markdown_body", -1)
        sc_idx = field_map.get("source_code", -1)
        for row in data.get("Values", []):
            if p_idx != -1 and row[p_idx] == "Content":
                html_val = (row[hb_idx] if hb_idx != -1 and hb_idx < len(row) else "") or ""
                md_val = (row[mb_idx] if mb_idx != -1 and mb_idx < len(row) else "") or ""
                sc_val = (row[sc_idx] if sc_idx != -1 and sc_idx < len(row) else "") or ""
                return html_val, md_val, sc_val
        return "", "", ""
    except Exception:
        return "", "", ""

def _get_page_body_v1(page_uuid):
    """Read html_body from pages_db/<uuid>.json — returns empty string if missing."""
    html_val, _, _ = _get_page_content_fields(page_uuid)
    return html_val

@app.route('/api/get/<uuid>')
def api_get(uuid):
    db.mount()
    pages = db.get_records("PageRecord")
    p = next((x for x in pages if x['page_uuid'] == uuid), None)
    if not p: return jsonify({"ok": False})
    content, markdown_body, _ = _get_page_content_fields(uuid)
    return jsonify({"ok": True, "page": p, "content": content, "markdown_body": markdown_body})

@app.route('/api/md2html', methods=['POST'])
def api_md2html():
    data = request.get_json(silent=True) or {}
    md_text = data.get("markdown") if data.get("markdown") is not None else request.form.get("markdown", "")
    fallback_title = data.get("fallback_title", "Untitled Document")
    parsed = convert_markdown_to_cms_article(md_text or "", fallback_title)
    wrapped_html = f'<article class="bejson-cms-article">\n{parsed["html_body"]}\n</article>'
    return jsonify({
        "ok": True,
        "success": True,
        "title": parsed["title"],
        "slug": parsed["slug"],
        "html": wrapped_html,
        "html_body": wrapped_html,
        "excerpt": parsed["excerpt"],
    })

@app.route('/api/save', methods=['POST'])
def api_save():
    data = request.json
    uuid_val = data.get('page_uuid') or str(uuid.uuid4())
    title    = data.get('title', 'Untitled')
    author   = data.get('author')
    cat      = data.get('category', 'Uncategorized')
    content  = data.get('content', '')
    tpl_key  = data.get('template_key', 'blank')
    featured_video = (data.get('featured_video_url') or '').strip() or None
    
    db.mount()
    existing = next((x for x in db.get_records("PageRecord") if x['page_uuid'] == uuid_val), None)

    if existing:
        # Update: only touch the fields this editor actually edits. item_type
        # and external_url are deliberately omitted - update_record() only
        # writes the keys it's given, so leaving these out preserves
        # whatever was already there. Including them unconditionally here
        # used to silently convert any external-link page back to a normal
        # page and wipe its URL on every single save via this editor.
        rec = {
            "page_title":   title,
            "page_slug":    re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-'),
            "page_cat_name": cat,
            "page_author_name": author,
            "page_template_key": tpl_key,
            "page_featured_video_url": featured_video,
        }
        db.update_record("PageRecord", "page_uuid", uuid_val, rec)
    else:
        rec = {
            "page_uuid":    uuid_val,
            "page_title":   title,
            "page_slug":    re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-'),
            "page_cat_name": cat,
            "page_type": "page",
            "page_created_at":   datetime.now().strftime("%Y-%m-%d"),
            "page_external_url": None,
            "page_author_name": author,
            "page_featured_img": None,
            "page_template_key": tpl_key,
            "page_featured_video_url": featured_video,
        }
        db.add_record("PageRecord", rec)
    
    # --- Content file in BEJSON 104db format (preserve existing markdown_body & source_code) ---
    pfile = os.path.join(PAGES_DB_DIR, f"{uuid_val}.json")
    os.makedirs(PAGES_DB_DIR, exist_ok=True)
    _, existing_md, existing_sc = _get_page_content_fields(uuid_val)
    markdown_body = data.get("markdown_body", existing_md)
    source_code = data.get("source_code", existing_sc)
    
    content_doc = {
        "Format": "BEJSON",
        "Format_Version": "104db",
        "Format_Creator": "Elton Boehnen",
        "Records_Type": ["PageMeta", "Content"],
        "Fields": [
            {"name": "Record_Type_Parent", "type": "string"},
            {"name": "meta_title", "type": "string"},
            {"name": "html_body", "type": "string"},
            {"name": "markdown_body", "type": "string"},
            {"name": "source_code", "type": "string"}
        ],
        "Values": [
            ["PageMeta", title, None, None, None],
            ["Content", None, content, markdown_body, source_code]
        ]
    }
    bejson_core_atomic_write(pfile, content_doc)
    return jsonify({"ok": True})

# =============================================================================
# MEDIA LIBRARY — shares the same physical ASSETS_DIR as Flask_CMS.py, so
# anything uploaded there (and its thumbnails) is immediately visible here.
# This app doesn't generate thumbnails itself; if one doesn't exist yet
# (Flask_CMS.py's background worker hasn't gotten to it), the original file
# is served instead - same fallback pattern Flask_CMS.py's own /assets/thumb
# route uses.
# =============================================================================

app.add_url_rule('/assets/<path:filename>', 'serve_asset_v2', serve_shared_asset)
app.add_url_rule('/assets/thumb/<path:filename>', 'serve_thumb_v2', serve_shared_thumb)

@app.route('/api/media/list')
def api_media_list():
    db.mount()
    assets = db.get_records("MediaAsset")
    assets.sort(key=lambda a: a.get('asset_uploaded_at') or '', reverse=True)
    return jsonify({"ok": True, "files": [
        {"filename": a.get("asset_filename"), "original_name": a.get("asset_original_name") or a.get("asset_filename"),
         "file_size": a.get("asset_file_size") or 0}
        for a in assets
    ]})

@app.route('/api/media/list_pdf')
def api_media_list_pdf():
    """Combined list for the Insert PDF modal: uploaded MediaAsset rows
    ending in .pdf, plus ExternalMedia rows tagged media_type == 'pdf'.
    Each item carries a ready-to-use `src` (relative ../../../assets/<file>
    for an uploaded asset, the raw absolute URL for an external link)."""
    db.mount()
    items = []
    try:
        for a in db.get_records("MediaAsset"):
            fname = a.get("asset_filename") or ""
            if fname.lower().endswith(".pdf"):
                items.append({
                    "kind": "asset",
                    "label": a.get("asset_original_name") or fname,
                    "src": f"../../../assets/{fname}",
                })
    except Exception:
        pass
    try:
        for ext in db.get_records("ExternalMedia"):
            if (ext.get("extmedia_type") or "").lower() == "pdf":
                url = ext.get("extmedia_url") or ""
                if url:
                    items.append({
                        "kind": "external",
                        "label": ext.get("extmedia_name") or url,
                        "src": url,
                    })
    except Exception:
        pass
    items.sort(key=lambda i: i["label"].lower())
    return jsonify({"ok": True, "items": items})

@app.route('/api/media/list_video')
def api_media_list_video():
    """Feeds the Insert YouTube modal's Saved Links tab: ExternalMedia rows
    tagged extmedia_type == 'video'. No MediaAsset side to this one --
    YouTube videos are never uploaded files, only saved external links."""
    db.mount()
    items = []
    try:
        for ext in db.get_records("ExternalMedia"):
            if (ext.get("extmedia_type") or "").lower() == "video":
                url = ext.get("extmedia_url") or ""
                if url:
                    items.append({
                        "label": ext.get("extmedia_name") or url,
                        "url": url,
                    })
    except Exception:
        pass
    items.sort(key=lambda i: i["label"].lower())
    return jsonify({"ok": True, "items": items})

@app.route('/api/media/rename', methods=['POST'])
def api_media_rename():
    data = request.json or {}
    filename = data.get('filename', '').strip()
    new_name = data.get('new_name', '').strip()
    if not filename or not new_name:
        return jsonify({"ok": False, "error": "filename and new_name are required"})
    db.mount()
    ok = db.update_record("MediaAsset", "asset_filename", filename, {"asset_original_name": new_name})
    return jsonify({"ok": ok})

@app.route('/api/delete/<uuid_val>', methods=['POST'])
def api_delete(uuid_val):
    db.mount()
    if db.delete_record("PageRecord", "page_uuid", uuid_val):
        path = os.path.join(PAGES_DB_DIR, f"{uuid_val}.json")
        if os.path.exists(path): os.remove(path)
        return jsonify({"ok": True})
    return jsonify({"ok": False})

@app.route('/api/category/add', methods=['POST'])
def api_add_cat():
    name = request.json.get('name')
    if not name: return jsonify({"ok": False})
    db.mount()
    db.add_record("Category", {"cat_name": name, "cat_slug": name.lower().replace(" ","-")})
    return jsonify({"ok": True})

@app.route('/api/settings/export_keys')
def api_export_keys():
    try:
        import subprocess
        # Simplified path for export - using project root/storage/tmp
        out_path = os.path.join(PROJECT_ROOT, "storage", "tmp", "gemini_keys_export.bejson")
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        subprocess.run(["python3", resolve_path("{INTERNAL_STORAGE}/Admin/tools/gemini_key_manager.py"), "--export", out_path], check=True)
        return jsonify({"ok": True, "msg": f"Template exported to {out_path}"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})

@app.route('/api/settings/import_keys', methods=['POST'])
def api_import_keys():
    try:
        file = request.files.get('file')
        if not file: return jsonify({"ok": False, "error": "No file uploaded"})
        tmp_path = os.path.join(PROJECT_ROOT, "storage", "tmp", "import_keys_upload.bejson")
        os.makedirs(os.path.dirname(tmp_path), exist_ok=True)
        file.save(tmp_path)
        import subprocess
        subprocess.run(["python3", resolve_path("{INTERNAL_STORAGE}/Admin/tools/gemini_key_manager.py"), "--import-keys", tmp_path], check=True)
        return jsonify({"ok": True, "msg": "Keys imported successfully."})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})

@app.route('/api/debug_keys')
def debug_keys():
    return jsonify({
        "path": GEMINI_KEYS_PATH,
        "exists": os.path.exists(GEMINI_KEYS_PATH),
        "keys_loaded": len(writer.api_keys),
        "cwd": os.getcwd()
    })

# =============================================================================
# UI RENDERING
# =============================================================================

DEFAULT_HTML = """<section class="content-block">
    <h1>New Content</h1>
    <p>Writing with BEJSON Editor v2...</p>
</section>"""

_SHELL = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BEJSON Editor v2</title>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Inter:wght@400;600;900&display=swap" rel="stylesheet">
    <style>
        :root { --bg: #050505; --card: #0c0c0c; --border: #1a1a1a; --acc: #de2626; --fg: #fff; --muted: #666; --font: 'Inter', sans-serif; --mono: 'JetBrains Mono', monospace; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: var(--bg); color: var(--fg); font-family: var(--font); line-height: 1.6; min-height: 100vh; overflow-x: hidden; }
        
        .header { height: 60px; background: #000; border-bottom: 1px solid var(--border); display: flex; align-items: center; padding: 0 80px; position: sticky; top: 0; z-index: 1000; }
        .logo { font-weight: 900; letter-spacing: -1px; font-size: 1.2rem; }
        .logo span { color: var(--acc); }

        .hamburger { 
            position: fixed; top: 15px; left: 20px; width: 30px; height: 22px; 
            cursor: pointer; z-index: 100001; display: flex; flex-direction: column; justify-content: space-between;
            background: rgba(0,0,0,0.3); padding: 5px; border-radius: 4px;
        }
        .hamburger div { width: 100%; height: 2px; background: #fff; border-radius: 1px; transition: 0.3s; }

        .side-menu { 
            position: fixed; top: 0; left: -320px; width: 300px; height: 100vh; 
            background: #080808; border-right: 1px solid var(--border); z-index: 100000; 
            transition: left 0.3s cubic-bezier(0.4, 0, 0.2, 1); padding: 80px 0 20px;
            box-shadow: 10px 0 30px rgba(0,0,0,0.5);
        }
        .side-menu.open { left: 0; }
        
        .menu-overlay {
            position: fixed; inset: 0; background: rgba(0,0,0,0.8); z-index: 99999;
            display: none; opacity: 0; transition: opacity 0.3s;
        }
        .menu-overlay.active { display: block; opacity: 1; }

        .side-menu a { 
            display: block; padding: 15px 30px; color: var(--muted); font-weight: 800; 
            text-transform: uppercase; font-size: 0.8rem; text-decoration: none; border-left: 4px solid transparent;
        }
        .side-menu a:hover, .side-menu a.active { color: #fff; background: rgba(222,38,38,0.1); border-left-color: var(--acc); }

        .container { max-width: 1100px; margin: 30px auto; padding: 0 20px; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .editor-wrap { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 25px; }
        
        .fg { display: flex; flex-direction: column; gap: 8px; margin-bottom: 20px; }
        label { font-size: 0.7rem; font-weight: 900; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; }
        input, select, textarea { background: #000; border: 1px solid var(--border); color: #fff; padding: 12px; border-radius: 8px; font-family: inherit; width: 100%; }
        textarea { min-height: 500px; font-family: var(--mono); font-size: 0.9rem; resize: vertical; }

        .btn { background: var(--acc); color: #fff; border: none; padding: 12px 24px; border-radius: 8px; font-weight: 900; cursor: pointer; text-transform: uppercase; font-size: 0.8rem; }
        .btn-black { background: #1a1a1a; border: 1px solid var(--border); }
        .btn-green { background: #059669; }
        .btn-kill { background: #991b1b; }
        .btn-sm { padding: 8px 16px; font-size: 0.7rem; }
        .flex-row { display: flex; gap: 15px; align-items: center; }

        /* Toolbar/button-bar rows: scroll horizontally on overflow instead of
           clipping or squishing buttons off-screen -- added pkg77, was the
           cause of Save/Delete etc. getting cut off at narrow widths. */
        .toolbar-row {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: nowrap;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
            padding-bottom: 6px;
            margin-bottom: -2px;
        }
        .toolbar-row::-webkit-scrollbar { height: 4px; }
        .toolbar-row::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }
        .toolbar-row > .btn, .toolbar-row > button { flex-shrink: 0; }
        .toolbar-row > label { flex-shrink: 0; white-space: nowrap; }

        /* Form-field-pair rows (selects/inputs, not buttons): stack instead
           of squishing on narrow screens. */
        @media (max-width: 620px) {
            .flex-row:not(.toolbar-row) { flex-wrap: wrap; }
            .flex-row:not(.toolbar-row) > .fg { min-width: 100%; }
        }

        /* Responsive grid & workflow bar helpers for Editor V2 and AI Content Architect */
        .editor-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .editor-grid-3 { display: grid; grid-template-columns: 1.2fr 0.9fr 1.2fr; gap: 15px; }
        .workflow-bar { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; }
        .workflow-bar .btn { flex-shrink: 0; }

        @media (max-width: 860px) {
            .editor-grid-3 { grid-template-columns: 1fr; }
        }
        @media (max-width: 640px) {
            .header { padding: 0 20px 0 60px; }
            .container { padding: 0 10px; margin: 15px auto; }
            .editor-wrap { padding: 14px; }
            .editor-grid-2 { grid-template-columns: 1fr; }
            .editor-grid-3 { grid-template-columns: 1fr; }
            .side-menu { width: 260px; }
            .workflow-bar .btn { width: 100%; text-align: center; }
        }
        
        .status-bar { margin-top: 15px; display: flex; justify-content: space-between; font-size: 0.7rem; font-family: var(--mono); color: var(--muted); }
        
        .task-card { background:#000; border:1px solid var(--border); border-radius:8px; padding:15px; margin-bottom:10px; }
        .task-title { font-weight:700; color:var(--acc); margin-bottom:10px; font-size:0.9rem; }
        
        .attachment-pill { padding:6px 12px; background:#111; border:1px solid var(--border); border-radius:20px; font-size:0.75rem; cursor:pointer; }
        .attachment-pill.selected { border-color:var(--acc); background:rgba(222,38,38,0.1); }

        .media-modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.75); z-index:3000; align-items:center; justify-content:center; }
        .media-modal-overlay.open { display:flex; }
        .media-modal-box { background:var(--card); border:1px solid var(--border); border-radius:12px; width:92%; max-width:960px; max-height:85vh; display:flex; flex-direction:column; overflow:hidden; }
        .media-modal-head { display:flex; justify-content:space-between; align-items:center; padding:16px 20px; border-bottom:1px solid var(--border); }
        .media-modal-head h3 { margin:0; font-size:1rem; }
        .media-modal-close { background:none; border:none; color:var(--muted); font-size:1.4rem; cursor:pointer; line-height:1; }
        .media-modal-grid { flex:1; overflow-y:auto; padding:20px; display:grid; grid-template-columns:repeat(auto-fill,minmax(130px,1fr)); gap:14px; }
        .media-modal-item { cursor:pointer; border-radius:8px; overflow:hidden; border:2px solid transparent; background:#000; aspect-ratio:1; position:relative; }
        .media-modal-item img { width:100%; height:100%; object-fit:cover; display:block; }
        .media-modal-item.selected { border-color:var(--acc); box-shadow:0 0 0 2px rgba(222,38,38,0.4); }
        .media-modal-item .fname { position:absolute; bottom:0; left:0; right:0; background:rgba(0,0,0,0.75); color:#fff; font-size:0.65rem; padding:4px 6px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .media-modal-actions { display:flex; gap:10px; padding:14px 20px; border-top:1px solid var(--border); align-items:center; }
        .media-modal-actions .selected-name { flex:1; font-size:0.8rem; color:var(--muted); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        .pdf-src-tab-v2 { flex:1; padding:8px 12px; background:transparent; border:none; border-bottom:2px solid transparent; color:var(--muted); font-size:.8rem; font-weight:700; cursor:pointer; }
        .pdf-src-tab-v2.active { color:var(--acc); border-bottom-color:var(--acc); }
    </style>
    <link rel="stylesheet" href="/fb/assets/becss-filepicker.css">
    <script src="/fb/assets/becss-filepicker.js"></script>
</head>
<body>

<div class="hamburger" id="h-btn" onclick="toggleMenu()">
    <div></div><div></div><div></div>
</div>

<div class="header">
    <div class="logo">BEJSON<span>_EDITOR_V2</span></div>
</div>

<div id="m-overlay" class="menu-overlay" onclick="toggleMenu()"></div>
<div id="s-menu" class="side-menu">
    <a href="#" onclick="showTab('editor')" class="tab-link active" id="l-editor">Editor Engine</a>
    <a href="#" onclick="showTab('tasking')" class="tab-link" id="l-tasking">AI Writer</a>
    <a href="#" onclick="showTab('context')" class="tab-link" id="l-context">Context & Attachments</a>
    <a href="#" onclick="showTab('settings')" class="tab-link" id="l-settings">System Config</a>
    <a href="{{ admin_url }}" style="margin-top:auto; border-top:1px solid var(--border);">Back to CMS</a>
</div>

<div class="container">
    {% with msgs = get_flashed_messages() %}{% for m in msgs %}<div style="padding:15px; background:rgba(222,38,38,0.1); border:1px solid var(--acc); color:var(--acc); border-radius:8px; margin-bottom:20px;">{{m}}</div>{% endfor %}{% endwith %}

    <div id="t-editor" class="tab-content active">
        <div class="editor-wrap">
            <div class="flex-row" style="margin-bottom:20px;">
                <div class="fg" style="flex:1;">
                    <label>Filter</label>
                    <select id="catSelect" onchange="filterPages()">
                        <option value="all">All Categories</option>
                        {% for c in categories %}<option value="{{c.cat_name}}">{{c.cat_name}}</option>{% endfor %}
                    </select>
                </div>
                <div class="fg" style="flex:1;">
                    <label>Target Page</label>
                    <select id="pageSelect">
                        <option value="">-- Select --</option>
                        {% for p in pages %}<option value="{{p.page_uuid}}" data-cat="{{p.page_cat_name}}">{{p.page_title}}</option>{% endfor %}
                    </select>
                </div>
            </div>
            <div class="flex-row toolbar-row" style="margin-bottom:25px;">
                <button class="btn btn-green" onclick="openNewModal()">New</button>
                <button class="btn btn-black" onclick="handleLoad()">Load</button>
                <button class="btn" onclick="savePage()">Save</button>
                <button class="btn btn-kill" onclick="deletePage()">Delete</button>
            </div>
            <div class="grid2" style="display:grid; grid-template-columns:1fr 1fr; gap:15px;">
                <div class="fg">
                    <label>Page Title</label>
                    <input type="text" id="edit_title" placeholder="Untitled">
                </div>
                <div class="fg">
                    <label>Template</label>
                    <select id="edit_template">
                        <option value="blank">Blank</option>
                        <option value="article">Article</option>
                        <option value="youtube_video">YouTube Video</option>
                        <option value="image_gallery">Gallery</option>
                        <option value="code">Code</option>
                    </select>
                </div>
            </div>
            <div class="grid2" style="display:grid; grid-template-columns:1fr 1fr; gap:15px;">
                <div class="fg">
                    <label>Author</label>
                    <select id="edit_author">
                        {% for a in authors %}<option value="{{a.author_display_name}}">{{a.author_display_name}}</option>{% endfor %}
                    </select>
                </div>
                <div class="fg">
                    <label>Category</label>
                    <select id="edit_category">
                        {% for c in categories %}<option value="{{c.cat_name}}">{{c.cat_name}}</option>{% endfor %}
                    </select>
                </div>
            </div>
            <div class="fg">
                <div class="flex-row toolbar-row" style="justify-content:space-between; margin-bottom:8px;">
                    <label style="margin:0;">Featured Video</label>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="toggleFeaturedVideoPanel()">Choose...</button>
                </div>
                <div id="featured-video-current" style="font-size:.8rem; color:var(--muted); margin-bottom:6px;">None selected</div>
                <div id="featured-video-panel" style="display:none; max-height:220px; overflow-y:auto; border:1px solid var(--border); border-radius:6px; padding:10px; background:var(--bg-secondary);">
                    <label style="display:flex; align-items:center; gap:8px; padding:4px 0; cursor:pointer;">
                        <input type="radio" name="featured_video_radio" value="" checked onchange="setFeaturedVideo('', 'None')">
                        <span>None</span>
                    </label>
                    <div id="featured-video-list"><span style="font-size:.8rem; color:var(--muted);">Loading saved videos...</span></div>
                </div>
                <input type="hidden" id="edit_featured_video_url" value="">
            </div>
            <div class="fg">
                <div class="flex-row toolbar-row" style="justify-content:space-between; margin-bottom:8px;">
                    <label style="margin:0;">Content</label>
                    <button type="button" class="btn btn-black btn-sm" onclick="openMediaPickerV2()">&#128247; Media</button>
                    <button type="button" class="btn btn-black btn-sm" onclick="openPdfPickerV2()">&#128196; PDF</button>
                    <button type="button" class="btn btn-black btn-sm" onclick="openYtPickerV2()">&#9654; YouTube</button>
                </div>
                <textarea id="html_body"></textarea>
            </div>
            <div class="status-bar" style="margin-top: 15px;">
                <div>SYSTEM: <span id="sys_status" style="color:var(--acc);">READY</span></div>
                <div id="status_msg">IDLE</div>
            </div>
        </div>
    </div>

    <div id="t-context" class="tab-content">
        <div class="editor-wrap">
            <h2>Context & Attachments</h2>
            <div id="path-config-root" style="background:#080808; padding:20px; border-radius:12px; border:1px solid var(--border); position:relative; margin-bottom:25px; margin-top:20px;">
                <h3 style="margin-bottom:15px; font-size:1rem;">Storage Path Configuration</h3>
                <div id="storage-radios" style="display:flex; gap:20px; margin-bottom:15px;"></div>
                <input type="text" id="path-input" oninput="autoSaveStorage()" style="font-family:var(--mono); font-size:0.85rem;">
                <div style="display:flex; align-items:center; gap:10px; border-top:1px solid var(--border); padding-top:20px; margin-top:15px;">
                    <button class="btn btn-black btn-sm" onclick="loadStorageFiles()">Scan Path</button>
                </div>
            </div>
            <div class="editor-wrap" style="background:rgba(255,255,255,0.02); border-style:dashed;">
                <h4 style="margin-bottom:15px;">Available Files</h4>
                <div id="attachment_list" style="display:flex; flex-wrap:wrap; gap:10px; min-height:40px;"></div>
            </div>
        </div>
    </div>

    <div id="t-tasking" class="tab-content">
        <div class="editor-wrap">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:15px;">
                <div>
                    <h2 style="margin-bottom:4px;">AI Writer</h2>
                    <div style="font-size:0.75rem; color:var(--muted);">4-Part BKS-1 Structured AI Writing Studio with 48k Context Bubble &amp; Author Precedence</div>
                </div>
                <span id="bks_job_badge" style="font-family:var(--mono); font-size:0.72rem; padding:5px 10px; border-radius:6px; background:#141414; border:1px solid var(--border); color:var(--muted);">No Active Job</span>
            </div>

            <!-- Saved Jobs + Target Post Row -->
            <div class="editor-grid-2" style="margin-bottom:15px; background:#080808; padding:15px; border-radius:10px; border:1px solid var(--border);">
                <div class="fg" style="margin-bottom:0;">
                    <label>Saved BKS-1 Blog Post Jobs</label>
                    <div style="display:flex; gap:8px;">
                        <select id="bks_job_select" onchange="if(this.value) loadBksJob(this.value)">
                            <option value="">-- New 4-Part Blog Job --</option>
                        </select>
                        <button type="button" class="btn btn-black btn-sm" onclick="refreshBksBootstrap()">&#8635;</button>
                    </div>
                </div>
                <div class="fg" style="margin-bottom:0;">
                    <label>Target Post to Overwrite on Approve</label>
                    <select id="bks_target_page">
                        <option value="">-- Create New CMS Post on Approve --</option>
                        {% for p in pages %}<option value="{{p.page_uuid}}">[Overwrite] {{p.page_title}} ({{p.page_cat_name}})</option>{% endfor %}
                    </select>
                </div>
            </div>

            <!-- Template + AI Provider + Model Row -->
            <div class="editor-grid-3" style="margin-bottom:15px;">
                <div class="fg" style="margin-bottom:0;">
                    <label>Blog Post Job Template (BookType)</label>
                    <select id="bks_template_select"></select>
                </div>
                <div class="fg" style="margin-bottom:0;">
                    <label>AI Provider (CLI_AI 48)</label>
                    <select id="bks_provider_select" onchange="syncBksModelOptions()"></select>
                </div>
                <div class="fg" style="margin-bottom:0;">
                    <label>AI Model</label>
                    <select id="bks_model_select"></select>
                </div>
            </div>

            <!-- Context Bubble Files (Select / Import Context Before Prompt) -->
            <div style="margin-bottom:15px; background:#080808; border:1px solid var(--border); border-radius:10px; padding:12px 15px;">
                <details id="bks_context_bubble_details">
                    <summary style="cursor:pointer; list-style:none; outline:none; user-select:none;">
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                            <div style="display:flex; align-items:center; gap:10px;">
                                <span style="font-family:var(--mono); font-size:0.72rem; background:#141414; padding:4px 8px; border-radius:4px; border:1px solid var(--border); font-weight:700;">CONTEXT BUBBLE (48K TOKENS)</span>
                                <span style="font-size:0.85rem; font-weight:700;">Reference Context Files (85%) &amp; Author Persona Directives (15% &mdash; Precedence Over Profile Instructions)</span>
                            </div>
                            <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                                <span id="bks_ctx_badge" style="font-family:var(--mono); font-size:0.72rem; color:var(--muted);">48k Max | 15% Author (~7.2k) | 85% Files (~40.8k)</span>
                                <button type="button" class="btn btn-black btn-sm" onclick="event.stopPropagation();openBksContextFilePicker()">+ Select / Import Context Files</button>
                            </div>
                        </div>
                    </summary>
                    <div style="margin-top:12px; padding-top:12px; border-top:1px solid var(--border);">
                        <div style="font-size:0.75rem; color:var(--muted); margin-bottom:10px; line-height:1.5;">
                            Assembled pre-prompt context combines <strong>Author Persona &amp; Directives (15% share, ~7.2k tokens)</strong>, which strictly overrides any conflicting profile guidelines, with <strong>Context Reference Files (85% share, ~40.8k tokens)</strong> instructed to study and learn silently without citation.
                        </div>
                        <div class="toolbar-row" style="margin-bottom:10px; display:flex; gap:8px; overflow-x:auto; flex-wrap:nowrap;">
                            <button type="button" class="btn btn-sm" style="flex-shrink:0;" onclick="openBksContextFilePicker()">Browse Server Files (File Importer Modal)</button>
                            <label class="btn btn-black btn-sm" style="flex-shrink:0; margin:0; cursor:pointer;">
                                Upload Local File
                                <input type="file" id="bks_ctx_upload_input" multiple style="display:none;" onchange="uploadBksContextFiles(this.files)">
                            </label>
                            <button type="button" class="btn btn-black btn-sm" style="flex-shrink:0;" onclick="refreshBksContextFiles()">&#8635; Refresh Bubble</button>
                        </div>
                        <div id="bks_ctx_file_list" style="display:flex; flex-direction:column; gap:6px; margin-bottom:10px;"></div>
                        <details style="margin-top:8px;">
                            <summary style="cursor:pointer; font-size:0.75rem; font-family:var(--mono); color:var(--muted);">Preview Injected Context Bubble Payload</summary>
                            <div style="margin-top:8px;">
                                <div style="display:flex; justify-content:flex-end; gap:6px; margin-bottom:6px;">
                                    <button type="button" class="btn btn-black btn-sm" onclick="selectAllText('bks_ctx_preview_box')">Select All</button>
                                    <button type="button" class="btn btn-black btn-sm" onclick="copyText('bks_ctx_preview_box', this)">Copy</button>
                                </div>
                                <textarea id="bks_ctx_preview_box" readonly style="min-height:140px; font-family:var(--mono); font-size:0.72rem; white-space:pre-wrap; word-wrap:break-word; overflow-wrap:break-word;" placeholder="No active context files selected."></textarea>
                            </div>
                        </details>
                    </div>
                </details>
            </div>

            <!-- Post Title + Topic / Prompt -->
            <div class="fg" style="margin-bottom:12px;">
                <label>Blog Post Title (Optional &mdash; Auto-Derived if Blank)</label>
                <input type="text" id="bks_title" placeholder="e.g. Zero-Dependency Local-First Architectures with BEJSON 104">
            </div>
            <div class="fg" style="margin-bottom:15px;">
                <label>Topic / Thesis / Architectural Brief</label>
                <textarea id="task_prompt" style="min-height:110px;" placeholder="Describe the blog post topic, key arguments, code examples, and target audience..."></textarea>
            </div>

            <!-- Workflow Action Bar: Single-Row H-Scroll -->
            <div class="workflow-bar toolbar-row" style="margin-bottom:20px; overflow-x:auto; -webkit-overflow-scrolling:touch; flex-wrap:nowrap; padding-bottom:6px; scrollbar-width:thin;">
                <button class="btn btn-green" style="flex-shrink:0; white-space:nowrap;" onclick="generateTaskPlan()">1. Generate Plan</button>
                <button class="btn btn-black" style="flex-shrink:0; white-space:nowrap;" onclick="saveBksPlanEdits()">Save Plan Edits</button>
                <button class="btn" style="flex-shrink:0; white-space:nowrap;" onclick="runNextBksPart()">2a. Run Next Part</button>
                <button class="btn" id="exec-btn" style="flex-shrink:0; white-space:nowrap;" onclick="runTaskingPlan()">2b. Run All &amp; Merge</button>
                <button class="btn btn-black" style="flex-shrink:0; white-space:nowrap;" onclick="mergeBksParts()">Re-Merge Parts</button>
                <button class="btn btn-green" style="background:#059669; border-color:#059669; flex-shrink:0; white-space:nowrap;" onclick="approveAndOverwriteTargetPost()">3. Approve &amp; Overwrite</button>
                <button class="btn btn-black" style="flex-shrink:0; white-space:nowrap;" onclick="importPlanToEditor()">Import to Editor</button>
            </div>

            <!-- 4-Part Plan & Execution Cards -->
            <div id="task_container"></div>

            <!-- Merged 4-Part Post Preview & Approve Panel -->
            <div id="bks_merged_panel" style="display:none; margin-top:25px; background:#080808; border:1px solid var(--border); border-radius:12px; padding:20px;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:15px;">
                    <div>
                        <h3 style="font-size:1rem; margin-bottom:4px;">Merged 4-Part Blog Post Preview</h3>
                        <div id="bks_merged_stats" style="font-size:0.75rem; color:var(--muted);">4 parts merged into unified Markdown + BEJSON CMS HTML</div>
                    </div>
                    <div style="display:flex; gap:10px; flex-wrap:wrap;">
                        <button class="btn btn-green btn-sm" onclick="approveAndOverwriteTargetPost()">&#10003; Approve &amp; Overwrite Target Post</button>
                        <button class="btn btn-black btn-sm" onclick="importPlanToEditor()">Load Merged HTML into Editor</button>
                    </div>
                </div>
                <div class="editor-grid-2" style="gap:15px;">
                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                            <label style="margin:0;">Merged 4-Part Markdown</label>
                            <div style="display:flex; gap:6px;">
                                <button type="button" class="btn btn-black btn-sm" onclick="selectAllText('bks_merged_md')">Select All</button>
                                <button type="button" class="btn btn-black btn-sm" onclick="copyText('bks_merged_md', this)">Copy</button>
                            </div>
                        </div>
                        <textarea id="bks_merged_md" style="min-height:280px; font-size:0.78rem; white-space:pre-wrap; word-wrap:break-word; overflow-wrap:break-word;"></textarea>
                    </div>
                    <div>
                        <label>Rendered CMS Article HTML Preview</label>
                        <div id="bks_merged_html_preview" style="min-height:280px; max-height:420px; overflow-y:auto; overflow-x:auto; max-width:100%; background:#0e0e0e; border:1px solid var(--border); border-radius:8px; padding:15px; font-size:0.85rem; line-height:1.6; white-space:normal; overflow-wrap:break-word;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="t-settings" class="tab-content">
        <div class="editor-wrap">
            <h2>System Config</h2>
            <div class="fg" style="margin-top:20px;">
                <label>Active Model</label>
                <select id="model_select"></select>
            </div>
            <div class="fg">
                <label>Key Registry</label>
                <div class="flex-row toolbar-row">
                    <button class="btn btn-black btn-sm" onclick="exportKeyTemplate()">Export</button>
                    <input type="file" id="key_import_file" accept=".bejson" style="max-width:200px; padding:5px; flex-shrink:0;">
                    <button class="btn btn-black btn-sm" onclick="importKeys()">Import</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="newModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.9); z-index:9000; align-items:center; justify-content:center;">
    <div class="editor-wrap" style="width:400px;">
        <h3>New Page</h3>
        <input type="text" id="modal_input" placeholder="Title..." style="margin:20px 0;">
        <div class="flex-row toolbar-row">
            <button class="btn" onclick="createNewDraft()">Create</button>
            <button class="btn btn-black" onclick="closeModal()">Cancel</button>
        </div>
    </div>
</div>

<input type="hidden" id="hidden_uuid">

<script>
const DEFAULT_HTML = `{{ default_html|safe }}`;
let currentPlan = [];
let currentBksJobSlug = '';
let currentBksDetail = null;
let bksProviderModels = {};

function toggleMenu() {
    document.getElementById('s-menu').classList.toggle('open');
    document.getElementById('m-overlay').classList.toggle('active');
}

function closeMenu() {
    const sMenu = document.getElementById('s-menu');
    const mOver = document.getElementById('m-overlay');
    if (sMenu) sMenu.classList.remove('open');
    if (mOver) mOver.classList.remove('active');
}

function showTab(id) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-link').forEach(l => l.classList.remove('active'));
    const targetTab = document.getElementById('t-' + id);
    const targetLink = document.getElementById('l-' + id);
    if(targetTab) targetTab.classList.add('active');
    if(targetLink) targetLink.classList.add('active');
    if(id === 'settings') loadModels();
    if(id === 'context') initStorage();
    if(id === 'tasking') refreshBksBootstrap();
    closeMenu();
}

function filterPages() {
    const cat = document.getElementById('catSelect').value;
    const opts = document.getElementById('pageSelect').options;
    for(let i=1; i < opts.length; i++) {
        opts[i].style.display = (cat === 'all' || opts[i].getAttribute('data-cat') === cat) ? 'block' : 'none';
    }
}

async function loadPageData(uuid) {
    const res = await fetch('/api/get/' + uuid);
    const data = await res.json();
    if(data.ok) {
        document.getElementById('hidden_uuid').value = uuid;
        document.getElementById('edit_title').value = data.page.page_title;
        document.getElementById('edit_author').value = data.page.page_author_name || '';
        document.getElementById('edit_category').value = data.page.page_cat_name || 'Uncategorized';
        document.getElementById('edit_template').value = data.page.page_template_key || 'blank';
        document.getElementById('edit_featured_video_url').value = data.page.page_featured_video_url || '';
        document.getElementById('featured-video-current').textContent = data.page.page_featured_video_url
            ? ('Selected: ' + data.page.page_featured_video_url) : 'None selected';
        _featuredVideoLoaded = false;
        document.getElementById('featured-video-panel').style.display = 'none';
        document.getElementById('html_body').value = data.content;
        const targetSel = document.getElementById('bks_target_page');
        if(targetSel) targetSel.value = uuid;
        const titleInput = document.getElementById('bks_title');
        if(titleInput && !titleInput.value) titleInput.value = data.page.page_title || '';
        document.getElementById('status_msg').innerText = 'LOADED';
    }
}

function handleLoad() {
    const uuid = document.getElementById('pageSelect').value;
    if(uuid) loadPageData(uuid);
}

async function savePage() {
    const uuid = document.getElementById('hidden_uuid').value;
    const title = document.getElementById('edit_title').value;
    const author = document.getElementById('edit_author').value;
    const cat = document.getElementById('edit_category').value;
    const content = document.getElementById('html_body').value;
    const template_key = document.getElementById('edit_template').value;
    const featured_video_url = document.getElementById('edit_featured_video_url').value;
    
    if(!title) { alert('Title required'); return; }

    const res = await fetch('/api/save', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({page_uuid: uuid, title, author, category: cat, content, template_key, featured_video_url})
    });
    if((await res.json()).ok) { alert('Saved!'); location.reload(); }
}

function openNewModal() { document.getElementById('newModal').style.display = 'flex'; }
function closeModal() { document.getElementById('newModal').style.display = 'none'; }
function createNewDraft() {
    const title = document.getElementById('modal_input').value;
    if(!title) return;
    document.getElementById('hidden_uuid').value = '';
    document.getElementById('edit_title').value = title;
    document.getElementById('edit_category').value = 'Uncategorized';
    document.getElementById('edit_featured_video_url').value = '';
    document.getElementById('featured-video-current').textContent = 'None selected';
    document.getElementById('featured-video-panel').style.display = 'none';
    _featuredVideoLoaded = false;
    document.getElementById('html_body').value = DEFAULT_HTML;
    closeModal();
}

async function deletePage() {
    const uuid = document.getElementById('hidden_uuid').value;
    if(!uuid || !confirm('Delete permanently?')) return;
    const res = await fetch('/api/delete/' + uuid, {method: 'POST'});
    if((await res.json()).ok) location.reload();
}

async function loadModels() {
    const res = await fetch('/api/settings/models');
    const data = await res.json();
    const sel = document.getElementById('model_select');
    sel.innerHTML = '';
    data.models.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m.model_id; opt.innerText = m.friendly_name;
        sel.appendChild(opt);
    });
}

// =============================================================================
// BKS-1 STANDARDIZED 4-PART BLOG POST JOB SYSTEM + CLI_AI 48 DISPATCH
// =============================================================================
async function refreshBksBootstrap() {
    try {
        const res = await fetch('/api/bks/bootstrap');
        const data = await res.json();
        if(!data.ok) return;

        // Populate Templates
        const tplSel = document.getElementById('bks_template_select');
        const prevTpl = tplSel.value || 'blog_post_4part';
        tplSel.innerHTML = '';
        (data.templates || []).forEach(t => {
            const opt = document.createElement('option');
            opt.value = t.type_id;
            opt.innerText = `${t.display_name} (${t.default_chapter_count} parts, ~${t.target_words_per_chapter}w/part)`;
            tplSel.appendChild(opt);
        });
        if([...tplSel.options].some(o => o.value === prevTpl)) tplSel.value = prevTpl;

        // Populate Providers & Models
        bksProviderModels = (data.ai && data.ai.models_by_provider) ? data.ai.models_by_provider : {};
        const provSel = document.getElementById('bks_provider_select');
        const prevProv = provSel.value || (data.ai && data.ai.default_provider) || 'gemini';
        provSel.innerHTML = '';
        ((data.ai && data.ai.providers) || ['gemini', 'groq', 'openrouter', 'openai']).forEach(p => {
            const opt = document.createElement('option');
            opt.value = p;
            opt.innerText = p.toUpperCase();
            provSel.appendChild(opt);
        });
        provSel.value = prevProv;
        syncBksModelOptions((data.ai && data.ai.default_model) || '');

        // Populate Saved Jobs
        const jobSel = document.getElementById('bks_job_select');
        const prevJob = currentBksJobSlug || jobSel.value;
        jobSel.innerHTML = '<option value="">-- New 4-Part Blog Job --</option>';
        (data.jobs || []).forEach(j => {
            const opt = document.createElement('option');
            opt.value = j.job_slug;
            opt.innerText = `[${j.status.toUpperCase()}] ${j.job_name} (${j.accepted_parts || 0}/${j.chapter_count || 4} parts)`;
            jobSel.appendChild(opt);
        });
        if(prevJob && [...jobSel.options].some(o => o.value === prevJob)) {
            jobSel.value = prevJob;
        }
        if(data.context_bubble) {
            renderBksContextBubbleState(data.context_bubble);
        }
    } catch(e) {
        console.error('BKS bootstrap error:', e);
    }
}

function renderBksContextBubbleState(ctxState) {
    const listEl = document.getElementById('bks_ctx_file_list');
    const badgeEl = document.getElementById('bks_ctx_badge');
    const previewEl = document.getElementById('bks_ctx_preview_box');
    if (!listEl) return;
    const files = (ctxState && ctxState.files) || [];
    const activeCount = (ctxState && ctxState.active_count) || 0;
    const estTokens = (ctxState && (ctxState.used_tokens || ctxState.estimated_tokens)) || 0;
    const maxTokens = (ctxState && ctxState.max_context_tokens) || 48000;
    if (badgeEl) {
        badgeEl.innerText = `48k Max (15% Author ~7.2k | 85% Files ~40.8k) | ${activeCount} active (${estTokens}/${maxTokens} tok)`;
        badgeEl.style.color = activeCount > 0 ? '#059669' : 'var(--muted)';
    }
    if (previewEl) {
        previewEl.value = (ctxState && ctxState.bubble_text) || '';
    }
    if (!files.length) {
        listEl.innerHTML = '<div style="font-size:0.75rem; color:var(--muted); padding:6px 0;">No context files imported yet. Click "+ Select / Import Context Files" to pick files with the File Importer modal.</div>';
        return;
    }
    listEl.innerHTML = '';
    files.forEach(f => {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex; justify-content:space-between; align-items:center; gap:10px; padding:6px 10px; background:#141414; border:1px solid var(--border); border-radius:6px; flex-wrap:wrap;';
        const safeName = (f.name || '').replace(/'/g, "\\'");
        row.innerHTML = `
            <label style="display:flex; align-items:center; gap:8px; margin:0; cursor:pointer; flex:1; min-width:180px;">
                <input type="checkbox" ${f.enabled ? 'checked' : ''} onchange="toggleBksContextFile('${safeName}', this.checked)" style="width:auto; margin:0;">
                <span style="font-family:var(--mono); font-size:0.78rem; font-weight:700; word-break:break-all;">${f.name}</span>
            </label>
            <div style="display:flex; align-items:center; gap:8px;">
                <span style="font-family:var(--mono); font-size:0.7rem; color:var(--muted);">${f.size || 0} B</span>
                <button type="button" class="btn btn-kill btn-sm" style="padding:3px 8px; font-size:0.68rem;" onclick="deleteBksContextFile('${safeName}')">Remove</button>
            </div>
        `;
        listEl.appendChild(row);
    });
}

async function refreshBksContextFiles() {
    try {
        const res = await fetch('/api/bks/context_files');
        const data = await res.json();
        if (data && data.ok) renderBksContextBubbleState(data);
    } catch (e) {
        console.error('Context bubble refresh error:', e);
    }
}

async function openBksContextFilePicker() {
    if (!window.CMSFilePicker) {
        document.getElementById('bks_ctx_upload_input').click();
        return;
    }
    try {
        const res = await window.CMSFilePicker.open({
            kind: 'code',
            multiple: true,
            allowUpload: true,
            title: 'Select Reference Files for AI Context Bubble'
        });
        if (!res) return;
        if (res.paths && res.paths.length) {
            document.getElementById('status_msg').innerText = 'IMPORTING CONTEXT BUBBLE FILES...';
            const r = await fetch('/api/bks/context_files/import_pick', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({paths: res.paths})
            });
            const data = await r.json();
            if (data.ok) {
                renderBksContextBubbleState(data);
                document.getElementById('bks_context_bubble_details').open = true;
                document.getElementById('status_msg').innerText = 'CONTEXT BUBBLE READY';
            } else {
                alert('Import failed: ' + (data.error || 'Unknown error'));
            }
        } else if (res.files && res.files.length) {
            await uploadBksContextFiles(res.files);
        }
    } catch (e) {
        console.error('File picker error:', e);
    }
}

async function uploadBksContextFiles(fileList) {
    if (!fileList || !fileList.length) return;
    const fd = new FormData();
    Array.from(fileList).forEach(f => fd.append('files', f));
    document.getElementById('status_msg').innerText = 'UPLOADING CONTEXT FILES...';
    const r = await fetch('/api/bks/context_files', {
        method: 'POST',
        body: fd
    });
    const data = await r.json();
    if (data.ok) {
        renderBksContextBubbleState(data);
        document.getElementById('bks_context_bubble_details').open = true;
        document.getElementById('status_msg').innerText = 'CONTEXT BUBBLE READY';
    } else {
        alert('Upload failed: ' + (data.error || 'Unknown error'));
    }
}

async function toggleBksContextFile(filename, enabled) {
    const r = await fetch('/api/bks/context_files/toggle', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({filename: filename, enabled: enabled})
    });
    const data = await r.json();
    if (data.ok) renderBksContextBubbleState(data);
}

async function deleteBksContextFile(filename) {
    const r = await fetch('/api/bks/context_files/delete', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({filename: filename})
    });
    const data = await r.json();
    if (data.ok) renderBksContextBubbleState(data);
}

function syncBksModelOptions(preferredModel) {
    const prov = document.getElementById('bks_provider_select').value || 'gemini';
    const modSel = document.getElementById('bks_model_select');
    const prevMod = preferredModel || modSel.value;
    modSel.innerHTML = '';
    const list = bksProviderModels[prov] || [];
    if(!list.length) {
        const opt = document.createElement('option');
        opt.value = 'gemini-2.5-flash';
        opt.innerText = 'Default Model';
        modSel.appendChild(opt);
        return;
    }
    list.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m.model_id;
        opt.innerText = `${m.friendly_name} (${m.model_id})`;
        modSel.appendChild(opt);
    });
    if(prevMod && [...modSel.options].some(o => o.value === prevMod)) {
        modSel.value = prevMod;
    }
}

async function loadBksJob(jobSlug) {
    if(!jobSlug) return;
    document.getElementById('status_msg').innerText = 'LOADING JOB...';
    const res = await fetch('/api/bks/job/' + encodeURIComponent(jobSlug));
    const data = await res.json();
    if(data.ok) {
        applyBksJobDetail(data);
        document.getElementById('status_msg').innerText = 'JOB LOADED';
    }
}

function applyBksJobDetail(data) {
    currentBksDetail = data;
    currentBksJobSlug = data.job_slug;
    const jobSel = document.getElementById('bks_job_select');
    if(jobSel && [...jobSel.options].some(o => o.value === data.job_slug)) {
        jobSel.value = data.job_slug;
    }
    if(data.book) {
        document.getElementById('bks_title').value = data.book.title || '';
        document.getElementById('task_prompt').value = data.book.topic || data.book.thesis || '';
        if(data.book.book_type_id) document.getElementById('bks_template_select').value = data.book.book_type_id;
    }
    if(data.link && data.link.target_page_uuid) {
        document.getElementById('bks_target_page').value = data.link.target_page_uuid;
    }
    const badge = document.getElementById('bks_job_badge');
    if(badge && data.book) {
        badge.innerText = `JOB: ${data.job_slug} | STATUS: ${(data.book.status || 'planned').toUpperCase()}`;
        badge.style.color = data.book.status === 'complete' ? '#059669' : 'var(--acc)';
    }
    currentPlan = (data.chapters || []).map((c, idx) => ({
        index: c.index || (idx + 1),
        title: c.title,
        prompt: c.brief,
        brief: c.brief,
        status: c.status,
        content: c.body_md || '',
        actual_words: c.actual_words || 0,
        target_words: c.target_words || 450,
        gate_Report: c.gate_Report || ''
    }));
    renderPlan();
    renderMergedPreview(data.merged_md || '', data.merged_html || '');
}

async function generateTaskPlan() {
    const prompt = document.getElementById('task_prompt').value;
    const title = document.getElementById('bks_title').value || document.getElementById('edit_title').value;
    const book_type_id = document.getElementById('bks_template_select').value || 'blog_post_4part';
    const provider = document.getElementById('bks_provider_select').value || 'gemini';
    const model_id = document.getElementById('bks_model_select').value || document.getElementById('model_select').value;
    const target_page_uuid = document.getElementById('bks_target_page').value || document.getElementById('hidden_uuid').value;
    const author_name = document.getElementById('edit_author').value;
    const category_name = document.getElementById('edit_category').value;

    if(!prompt && !title) { alert('Enter a Topic / Prompt or Blog Post Title first.'); return; }
    document.getElementById('status_msg').innerText = 'GENERATING 4-PART BKS-1 PLAN...';
    const res = await fetch('/api/bks/create_plan', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            topic: prompt || title,
            title: title,
            book_type_id: book_type_id,
            provider: provider,
            model_id: model_id,
            target_page_uuid: target_page_uuid,
            author_name: author_name,
            category_name: category_name
        })
    });
    const data = await res.json();
    if(data.ok) {
        await refreshBksBootstrap();
        applyBksJobDetail(data);
        document.getElementById('status_msg').innerText = '4-PART PLAN READY';
    } else {
        alert('Plan generation failed: ' + (data.error || 'Unknown error'));
        document.getElementById('status_msg').innerText = 'ERROR';
    }
}

function selectAllText(targetId) {
    const el = document.getElementById(targetId);
    if (!el) return;
    el.focus();
    el.select();
    el.setSelectionRange(0, 99999);
}

async function copyText(targetId, btnElement) {
    const el = document.getElementById(targetId);
    if (!el) return;
    try {
        await navigator.clipboard.writeText(el.value || el.innerText);
        const originalText = btnElement.innerText;
        btnElement.innerText = "Copied!";
        setTimeout(() => {
            btnElement.innerText = originalText;
        }, 1500);
    } catch(err) {
        console.error("Copy failed", err);
    }
}

function renderPlan() {
    const cont = document.getElementById('task_container');
    cont.innerHTML = '';
    currentPlan.forEach((t, i) => {
        const partIdx = t.index || (i + 1);
        const statusColor = t.status === 'accepted' ? '#059669' : (t.status === 'rejected' ? '#dc2626' : 'var(--muted)');
        const isCompleted = t.status === 'accepted';
        const div = document.createElement('div');
        div.className = 'task-card';
        div.style.marginBottom = '12px';
        div.innerHTML = `
            <details ${isCompleted ? '' : 'open'} style="width:100%;">
                <summary style="cursor:pointer; list-style:none; outline:none; user-select:none;">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; padding:4px 0;">
                        <div style="display:flex; align-items:center; gap:10px; flex:1; min-width:200px;">
                            <span style="font-family:var(--mono); font-size:0.75rem; background:#151515; padding:4px 8px; border-radius:4px; border:1px solid var(--border); flex-shrink:0;">PART ${partIdx}/4</span>
                            <input type="text" id="bks-part-title-${i}" value="${(t.title || '').replace(/"/g, '&quot;')}" style="font-weight:700; padding:6px 10px; font-size:0.9rem; flex:1; min-width:0;" onclick="event.stopPropagation();">
                        </div>
                        <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                            <span id="task-res-${i}" style="font-family:var(--mono); font-size:0.72rem; color:${statusColor};">${(t.status || 'planned').toUpperCase()} (${t.actual_words || 0}/${t.target_words || 450}w)</span>
                            <button type="button" class="btn btn-sm" onclick="event.stopPropagation();runSingleBksPart(${partIdx}, ${i})">&#9654; Run Part ${partIdx}</button>
                        </div>
                    </div>
                </summary>
                <div style="margin-top:12px; padding-top:12px; border-top:1px solid var(--border);">
                    <div style="margin-bottom:10px;">
                        <label style="font-size:0.65rem;">Part ${partIdx} Brief &amp; Instructions</label>
                        <textarea id="bks-part-brief-${i}" style="min-height:60px; font-size:0.8rem; white-space:pre-wrap; word-wrap:break-word;">${t.brief || t.prompt || ''}</textarea>
                    </div>
                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                            <label style="font-size:0.65rem; margin:0;">Part ${partIdx} Generated Markdown Content (${(t.content || '').length} chars)</label>
                            <div style="display:flex; gap:6px;">
                                <button type="button" class="btn btn-black btn-sm" style="font-size:0.65rem; padding:2px 8px;" onclick="selectAllText('bks-part-body-${i}')">Select All</button>
                                <button type="button" class="btn btn-black btn-sm" style="font-size:0.65rem; padding:2px 8px;" onclick="copyText('bks-part-body-${i}', this)">Copy</button>
                            </div>
                        </div>
                        <textarea id="bks-part-body-${i}" style="min-height:140px; font-size:0.8rem; white-space:pre-wrap; word-wrap:break-word;">${t.content || ''}</textarea>
                    </div>
                </div>
            </details>
        `;
        cont.appendChild(div);
    });
}

function collectPartEditsFromDom() {
    const parts = [];
    for(let i=0; i<currentPlan.length; i++) {
        const titleEl = document.getElementById(`bks-part-title-${i}`);
        const briefEl = document.getElementById(`bks-part-brief-${i}`);
        const bodyEl = document.getElementById(`bks-part-body-${i}`);
        parts.push({
            index: currentPlan[i].index || (i + 1),
            title: titleEl ? titleEl.value : currentPlan[i].title,
            brief: briefEl ? briefEl.value : (currentPlan[i].brief || currentPlan[i].prompt),
            body_md: bodyEl ? bodyEl.value : (currentPlan[i].content || '')
        });
    }
    return parts;
}

async function saveBksPlanEdits() {
    if(!currentBksJobSlug) { alert('Generate or load a BKS-1 Blog Job first.'); return; }
    const parts = collectPartEditsFromDom();
    const res = await fetch('/api/bks/update_plan', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            job_slug: currentBksJobSlug,
            title: document.getElementById('bks_title').value,
            topic: document.getElementById('task_prompt').value,
            target_page_uuid: document.getElementById('bks_target_page').value,
            provider: document.getElementById('bks_provider_select').value,
            model_id: document.getElementById('bks_model_select').value,
            author_name: document.getElementById('edit_author').value,
            category_name: document.getElementById('edit_category').value,
            parts: parts
        })
    });
    const data = await res.json();
    if(data.ok) {
        applyBksJobDetail(data);
        document.getElementById('status_msg').innerText = 'PLAN SAVED';
    }
}

async function runSingleBksPart(partIndex, domIdx) {
    if(!currentBksJobSlug) {
        await generateTaskPlan();
        if(!currentBksJobSlug) return;
    } else {
        await saveBksPlanEdits();
    }
    const statusEl = document.getElementById(`task-res-${domIdx}`);
    if(statusEl) { statusEl.innerText = 'EXECUTING VIA CLI_AI 48...'; statusEl.style.color = '#f59e0b'; }
    document.getElementById('status_msg').innerText = `WRITING PART ${partIndex}/4...`;

    const res = await fetch('/api/bks/execute_part', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            job_slug: currentBksJobSlug,
            part_index: partIndex,
            provider: document.getElementById('bks_provider_select').value || 'gemini',
            model_id: document.getElementById('bks_model_select').value || document.getElementById('model_select').value,
            author_name: document.getElementById('edit_author').value
        })
    });
    const data = await res.json();
    if(data.ok && data.detail) {
        applyBksJobDetail(data.detail);
        await refreshBksBootstrap();
        document.getElementById('status_msg').innerText = `PART ${partIndex} COMPLETED`;
    } else {
        if(statusEl) { statusEl.innerText = 'ERROR'; statusEl.style.color = '#dc2626'; }
        alert('Part execution error: ' + (data.error || 'Unknown error'));
    }
}

async function runNextBksPart() {
    if(!currentBksJobSlug) {
        await generateTaskPlan();
        if(!currentBksJobSlug) return;
    }
    const nextIdx = currentPlan.findIndex(p => p.status !== 'accepted');
    const targetIdx = nextIdx >= 0 ? nextIdx : 0;
    await runSingleBksPart(currentPlan[targetIdx].index || (targetIdx + 1), targetIdx);
}

async function runTaskingPlan() {
    if(!currentBksJobSlug) {
        await generateTaskPlan();
        if(!currentBksJobSlug) return;
    } else {
        await saveBksPlanEdits();
    }
    for(let i=0; i<currentPlan.length; i++) {
        const partIdx = currentPlan[i].index || (i + 1);
        await runSingleBksPart(partIdx, i);
    }
    await mergeBksParts();
    document.getElementById('status_msg').innerText = 'ALL 4 PARTS EXECUTED & MERGED';
}

async function mergeBksParts() {
    if(!currentBksJobSlug) return;
    await saveBksPlanEdits();
    const res = await fetch('/api/bks/merge', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({job_slug: currentBksJobSlug})
    });
    const data = await res.json();
    if(data.ok) {
        if(data.detail) applyBksJobDetail(data.detail);
        renderMergedPreview(data.merged_md || '', data.merged_html || '');
        document.getElementById('status_msg').innerText = '4 PARTS MERGED';
    }
}

function renderMergedPreview(mergedMd, mergedHtml) {
    const panel = document.getElementById('bks_merged_panel');
    if(!mergedMd && !mergedHtml) {
        panel.style.display = 'none';
        return;
    }
    panel.style.display = 'block';
    document.getElementById('bks_merged_md').value = mergedMd || '';
    document.getElementById('bks_merged_html_preview').innerHTML = mergedHtml || '';
}

async function approveAndOverwriteTargetPost() {
    if(!currentBksJobSlug) { alert('No active BKS-1 Blog Post Job to approve.'); return; }
    await saveBksPlanEdits();
    const target_page_uuid = document.getElementById('bks_target_page').value || document.getElementById('hidden_uuid').value;
    const title = document.getElementById('bks_title').value || document.getElementById('edit_title').value;
    const author_name = document.getElementById('edit_author').value;
    const category_name = document.getElementById('edit_category').value;
    const template_key = document.getElementById('edit_template').value;

    const actionDesc = target_page_uuid
        ? `Approve merged 4-part post and OVERWRITE target post (${target_page_uuid})?`
        : `Approve merged 4-part post and create a new CMS post "${title}"?`;
    if(!confirm(actionDesc)) return;

    document.getElementById('status_msg').innerText = 'APPROVING & OVERWRITING TARGET POST...';
    const res = await fetch('/api/bks/approve', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            job_slug: currentBksJobSlug,
            target_page_uuid: target_page_uuid,
            title: title,
            author_name: author_name,
            category_name: category_name,
            template_key: template_key
        })
    });
    const data = await res.json();
    if(data.ok) {
        document.getElementById('hidden_uuid').value = data.target_page_uuid;
        document.getElementById('bks_target_page').value = data.target_page_uuid;
        document.getElementById('edit_title').value = data.title || title;
        document.getElementById('html_body').value = data.merged_html || '';
        await loadPageData(data.target_page_uuid);
        await refreshBksBootstrap();
        document.getElementById('status_msg').innerText = 'APPROVED & TARGET POST OVERWRITTEN';
        alert(`Approved! Target post "${data.title}" (${data.target_page_uuid}) has been overwritten with the merged 4-part post (${data.word_count} words).`);
        showTab('editor');
    } else {
        alert('Approve failed: ' + (data.error || 'Unknown error'));
    }
}

function importPlanToEditor() {
    const mergedHtml = (currentBksDetail && currentBksDetail.merged_html) ? currentBksDetail.merged_html : '';
    if(mergedHtml) {
        document.getElementById('html_body').value = mergedHtml;
        if(currentBksDetail.book && currentBksDetail.book.title && !document.getElementById('edit_title').value) {
            document.getElementById('edit_title').value = currentBksDetail.book.title;
        }
        showTab('editor');
        return;
    }
    let combined = "";
    currentPlan.forEach(t => {
        if(t.content) combined += `<h2>${t.title}</h2>\n${t.content}\n\n`;
    });
    document.getElementById('html_body').value = combined;
    showTab('editor');
}

// Storage Component
let storagePaths = {};
async function initStorage() {
    const res = await fetch('/api/storage/config');
    const data = await res.json();
    storagePaths = data.paths;
    renderStorageRadios();
    loadAttachmentList();
}

function renderStorageRadios() {
    const cont = document.getElementById('storage-radios');
    cont.innerHTML = '';
    for(const [label, info] of Object.entries(storagePaths)) {
        const div = document.createElement('div');
        div.innerHTML = `<label style="display:flex; align-items:center; gap:8px; cursor:pointer; text-transform:none;">
            <input type="radio" name="spath" value="${label}" ${info.enabled?'checked':''} onchange="setStorage('${label}')"> ${label}
        </label>`;
        cont.appendChild(div);
    }
}

async function setStorage(label) {
    for(let k in storagePaths) storagePaths[k].enabled = (k === label);
    document.getElementById('path-input').value = storagePaths[label].path;
    await fetch('/api/storage/config', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify(storagePaths)
    });
}

async function loadAttachmentList() {
    const res = await fetch('/api/context/list');
    const data = await res.json();
    const cont = document.getElementById('attachment_list');
    cont.innerHTML = '';
    data.files.forEach(f => {
        const pill = document.createElement('div');
        pill.className = 'attachment-pill';
        pill.innerText = f;
        cont.appendChild(pill);
    });
}

window.onload = () => {
    loadModels();
    refreshBksBootstrap();
};

// =============================================================================
// MEDIA PICKER — grid gallery of the shared Media Library. Click an image to
// select it (highlight), then Copy Tag or Rename from the action bar below
// the grid. Rename only changes the display name (original_name) - the
// physical stored filename never changes, so anything already referencing
// it keeps working, matching Flask_CMS.py's own Media Library behavior.
// =============================================================================
var _mediaPickerSelected = null;

function openMediaPickerV2() {
    document.getElementById('media-modal-v2').classList.add('open');
    loadMediaGridV2();
}

function closeMediaPickerV2() {
    document.getElementById('media-modal-v2').classList.remove('open');
    _mediaPickerSelected = null;
    updateMediaActionBarV2();
}

function loadMediaGridV2() {
    const grid = document.getElementById('media-modal-grid-v2');
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--muted);">Loading…</div>';
    fetch('/api/media/list').then(r => r.json()).then(d => {
        grid.innerHTML = '';
        if (!d.ok || !d.files || !d.files.length) {
            grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--muted);">Media library is empty.</div>';
            return;
        }
        d.files.forEach(f => {
            const item = document.createElement('div');
            item.className = 'media-modal-item';
            item.dataset.filename = f.filename;
            item.innerHTML = '<img src="/assets/thumb/' + f.filename + '" loading="lazy">' +
                '<div class="fname">' + f.original_name + '</div>';
            item.onclick = () => selectMediaItemV2(f.filename, f.original_name, item);
            grid.appendChild(item);
        });
    });
}

function selectMediaItemV2(filename, originalName, el) {
    document.querySelectorAll('.media-modal-item.selected').forEach(x => x.classList.remove('selected'));
    el.classList.add('selected');
    _mediaPickerSelected = { filename: filename, original_name: originalName };
    updateMediaActionBarV2();
}

function updateMediaActionBarV2() {
    const bar = document.getElementById('media-modal-actions-v2');
    const nameEl = document.getElementById('media-modal-selected-name-v2');
    if (_mediaPickerSelected) {
        bar.style.display = 'flex';
        nameEl.textContent = _mediaPickerSelected.original_name;
    } else {
        bar.style.display = 'none';
    }
}

function copyMediaTagV2() {
    if (!_mediaPickerSelected) return;
    const tag = '<img src="/assets/' + _mediaPickerSelected.filename + '" alt="' + _mediaPickerSelected.original_name + '">';
    const ta = document.createElement('textarea');
    ta.value = tag;
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(ta);
    document.getElementById('status_msg').textContent = 'Image tag copied to clipboard';
}

function renameMediaV2() {
    if (!_mediaPickerSelected) return;
    const newName = prompt('New display name:', _mediaPickerSelected.original_name);
    if (newName === null || newName.trim() === '') return;
    fetch('/api/media/rename', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: _mediaPickerSelected.filename, new_name: newName })
    }).then(r => r.json()).then(d => {
        if (d.ok) {
            _mediaPickerSelected.original_name = newName;
            updateMediaActionBarV2();
            loadMediaGridV2();
        } else {
            alert('Rename failed: ' + (d.error || 'unknown error'));
        }
    });
}

// =============================================================================
// PDF PICKER — separate from the Image media picker above (that grid always
// renders <img> thumbs, which breaks for non-image assets). Lists uploaded
// PDFs + saved External Media Links tagged type=pdf, or a one-off pasted
// URL, then inserts the bej-pdf-wrap <object> embed directly into the
// html_body textarea at the current cursor position.
// =============================================================================
var _pdfSelectedV2 = null;

function openPdfPickerV2() {
    _pdfSelectedV2 = null;
    document.getElementById('pdf-modal-selected-name-v2').textContent = '';
    pdfShowTabV2('library');
    document.getElementById('pdf-modal-v2').classList.add('open');
    loadPdfListV2();
}

function closePdfPickerV2() {
    document.getElementById('pdf-modal-v2').classList.remove('open');
}

function pdfShowTabV2(which) {
    const libTab = document.getElementById('pdfTabLibraryV2'), urlTab = document.getElementById('pdfTabUrlV2');
    const libPane = document.getElementById('pdfPaneLibraryV2'), urlPane = document.getElementById('pdfPaneUrlV2');
    if (which === 'library') {
        libTab.classList.add('active'); urlTab.classList.remove('active');
        libPane.style.display = 'block'; urlPane.style.display = 'none';
    } else {
        urlTab.classList.add('active'); libTab.classList.remove('active');
        urlPane.style.display = 'block'; libPane.style.display = 'none';
    }
}

function loadPdfListV2() {
    const pane = document.getElementById('pdfPaneLibraryV2');
    fetch('/api/media/list_pdf').then(r => r.json()).then(d => {
        pane.innerHTML = '';
        if (!d.ok || !d.items || !d.items.length) {
            pane.innerHTML = '<div style="text-align:center;color:var(--muted);font-size:.85rem;">No PDFs yet — upload one via Media, or use the External URL tab.</div>';
            return;
        }
        d.items.forEach(item => {
            const row = document.createElement('div');
            row.style = 'padding:8px 4px;cursor:pointer;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;font-size:.85rem;';
            row.innerHTML = '<span>' + (item.kind === 'external' ? '&#128279;' : '&#128196;') + '</span>'
                + '<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + item.label + '</span>';
            row.onclick = () => {
                pane.querySelectorAll('div').forEach(r => r.style.background = '');
                row.style.background = 'rgba(222,38,38,0.12)';
                _pdfSelectedV2 = { src: item.src, label: item.label };
                document.getElementById('pdf-modal-selected-name-v2').textContent = item.label;
            };
            pane.appendChild(row);
        });
    });
}

function insertPdfV2() {
    const usingUrl = document.getElementById('pdfPaneUrlV2').style.display !== 'none';
    const caption = document.getElementById('pdfCaptionV2').value.trim();
    let src, label;
    if (usingUrl) {
        src = document.getElementById('pdfExternalUrlV2').value.trim();
        if (!src) { alert('Enter a PDF URL first.'); return; }
        label = caption || src;
    } else {
        if (!_pdfSelectedV2) { alert('Select a PDF from the list, or switch to the External URL tab.'); return; }
        src = _pdfSelectedV2.src;
        label = caption || _pdfSelectedV2.label;
    }
    const captionHtml = caption
        ? '\\n<p style="font-size:.9rem;color:#666;margin-top:10px;text-align:center;">' + caption + '</p>'
        : '';
    const snippet = '\\n<div class="bej-pdf-wrap" style="width:100%;margin:30px 0;border:1px solid #e5e5e5;border-radius:4px;overflow:hidden;">\\n'
        + '  <object data="' + src + '" type="application/pdf" style="width:100%;height:820px;display:block;">\\n'
        + '    <div style="padding:40px;text-align:center;background:#f8f8f8;">\\n'
        + '      <p style="font-size:1.1rem;margin-bottom:16px;">Your browser cannot display this PDF inline.</p>\\n'
        + '      <a href="' + src + '" download style="display:inline-block;padding:12px 28px;background:#DE2626;color:#fff;font-weight:700;text-decoration:none;border-radius:4px;">⬇ Download PDF</a>\\n'
        + '    </div>\\n'
        + '  </object>\\n'
        + '</div>' + captionHtml + '\\n';
    const ta = document.getElementById('html_body');
    const pos = ta.selectionStart;
    ta.setRangeText(snippet, pos, pos, 'end');
    ta.focus();
    closePdfPickerV2();
    document.getElementById('pdfExternalUrlV2').value = '';
    document.getElementById('pdfCaptionV2').value = '';
    _pdfSelectedV2 = null;
}

// ── YouTube picker (same "Saved Links / Paste URL" pattern as PDF) ──
var _ytSelectedV2 = null;

function openYtPickerV2() {
    _ytSelectedV2 = null;
    document.getElementById('yt-modal-selected-name-v2').textContent = '';
    ytShowTabV2('library');
    document.getElementById('yt-modal-v2').classList.add('open');
    loadYtListV2();
}

function closeYtPickerV2() {
    document.getElementById('yt-modal-v2').classList.remove('open');
}

function ytShowTabV2(which) {
    const libTab = document.getElementById('ytTabLibraryV2'), urlTab = document.getElementById('ytTabUrlV2');
    const libPane = document.getElementById('ytPaneLibraryV2'), urlPane = document.getElementById('ytPaneUrlV2');
    if (which === 'library') {
        libTab.classList.add('active'); urlTab.classList.remove('active');
        libPane.style.display = 'block'; urlPane.style.display = 'none';
    } else {
        urlTab.classList.add('active'); libTab.classList.remove('active');
        urlPane.style.display = 'block'; libPane.style.display = 'none';
    }
}

function loadYtListV2() {
    const pane = document.getElementById('ytPaneLibraryV2');
    fetch('/api/media/list_video').then(r => r.json()).then(d => {
        pane.innerHTML = '';
        if (!d.ok || !d.items || !d.items.length) {
            pane.innerHTML = '<div style="text-align:center;color:var(--muted);font-size:.85rem;">No saved video links yet — add one via Media &rarr; Links (type: Video), or use the Paste URL/ID tab.</div>';
            return;
        }
        d.items.forEach(item => {
            const row = document.createElement('div');
            row.style = 'padding:8px 4px;cursor:pointer;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;font-size:.85rem;';
            row.innerHTML = '<span>&#9654;</span>'
                + '<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + item.label + '</span>';
            row.onclick = () => {
                pane.querySelectorAll('div').forEach(r => r.style.background = '');
                row.style.background = 'rgba(222,38,38,0.12)';
                _ytSelectedV2 = { url: item.url, label: item.label };
                document.getElementById('yt-modal-selected-name-v2').textContent = item.label;
            };
            pane.appendChild(row);
        });
    });
}

function ytIdFromUrlV2(raw) {
    raw = raw.trim();
    if (/^[A-Za-z0-9_-]{11}$/.test(raw)) return raw;
    const m = raw.match(/(?:v=|youtu\\.be\\/|embed\\/)([A-Za-z0-9_-]{11})/);
    return m ? m[1] : null;
}

function insertYtV2() {
    const usingUrl = document.getElementById('ytPaneUrlV2').style.display !== 'none';
    const caption = document.getElementById('ytCaptionV2').value.trim();
    let raw, label;
    if (usingUrl) {
        raw = document.getElementById('ytExternalUrlV2').value.trim();
        if (!raw) { alert('Enter a YouTube URL or ID first.'); return; }
        label = caption || raw;
    } else {
        if (!_ytSelectedV2) { alert('Select a saved video from the list, or switch to the Paste URL/ID tab.'); return; }
        raw = _ytSelectedV2.url;
        label = caption || _ytSelectedV2.label;
    }
    const vid = ytIdFromUrlV2(raw);
    if (!vid) { alert('Could not extract a YouTube video ID from that URL. Try pasting the full watch URL or just the 11-character ID.'); return; }
    const captionHtml = caption
        ? '\\n<p style="font-size:.9rem;color:#666;margin-top:10px;text-align:center;font-style:italic;">' + caption + '</p>'
        : '';
    const snippet = '\\n<div class="bej-video-wrap" style="max-width:800px;margin:40px auto;">\\n'
        + '  <div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:8px;border:1px solid #333;background:#000;">\\n'
        + '    <iframe\\n'
        + '      src="https://www.youtube.com/embed/' + vid + '"\\n'
        + '      title="' + (caption || 'YouTube Video') + '"\\n'
        + '      frameborder="0"\\n'
        + '      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"\\n'
        + '      allowfullscreen\\n'
        + '      style="position:absolute;top:0;left:0;width:100%;height:100%;">\\n'
        + '    </iframe>\\n'
        + '  </div>' + captionHtml + '\\n'
        + '</div>\\n';
    const ta = document.getElementById('html_body');
    const pos = ta.selectionStart;
    ta.setRangeText(snippet, pos, pos, 'end');
    ta.focus();
    closeYtPickerV2();
    document.getElementById('ytExternalUrlV2').value = '';
    document.getElementById('ytCaptionV2').value = '';
    _ytSelectedV2 = null;
}

// ── Featured Video (radio-select, separate from in-body Insert) ──
let _featuredVideoLoaded = false;
function toggleFeaturedVideoPanel() {
    const panel = document.getElementById('featured-video-panel');
    const showing = panel.style.display !== 'none';
    panel.style.display = showing ? 'none' : '';
    if (!showing && !_featuredVideoLoaded) loadFeaturedVideoOptions();
}
function loadFeaturedVideoOptions() {
    _featuredVideoLoaded = true;
    fetch('/api/media/list_video').then(r => r.json()).then(items => {
        const list = document.getElementById('featured-video-list');
        if (!items || !items.length) {
            list.innerHTML = '<span style="font-size:.8rem; color:var(--muted);">No saved YouTube videos yet -- add one via the Media Library\\'s YouTube tab.</span>';
            return;
        }
        const currentUrl = document.getElementById('edit_featured_video_url').value;
        list.innerHTML = '';
        items.forEach(function(item, i) {
            const id = 'fv-radio-' + i;
            const row = document.createElement('label');
            row.style = 'display:flex; align-items:center; gap:8px; padding:4px 0; cursor:pointer;';
            const checked = (item.url === currentUrl) ? 'checked' : '';
            row.innerHTML = '<input type="radio" name="featured_video_radio" id="' + id + '" ' + checked + '>'
                + '<span>' + item.label.replace(/</g, '&lt;') + '</span>';
            row.querySelector('input').addEventListener('change', function() { setFeaturedVideo(item.url, item.label); });
            list.appendChild(row);
        });
    }).catch(() => {
        document.getElementById('featured-video-list').innerHTML = '<span style="font-size:.8rem; color:#f87171;">Failed to load saved videos.</span>';
    });
}
function setFeaturedVideo(url, label) {
    document.getElementById('edit_featured_video_url').value = url;
    document.getElementById('featured-video-current').textContent = url ? ('Selected: ' + label) : 'None selected';
}
</script>

<div id="media-modal-v2" class="media-modal-overlay" onclick="if(event.target===this) closeMediaPickerV2()">
    <div class="media-modal-box">
        <div class="media-modal-head">
            <h3>Media Library</h3>
            <button type="button" class="media-modal-close" onclick="closeMediaPickerV2()">&times;</button>
        </div>
        <div id="media-modal-grid-v2" class="media-modal-grid"></div>
        <div id="media-modal-actions-v2" class="media-modal-actions" style="display:none;">
            <span id="media-modal-selected-name-v2" class="selected-name"></span>
            <button type="button" class="btn btn-black btn-sm" onclick="renameMediaV2()">Rename</button>
            <button type="button" class="btn btn-sm" onclick="copyMediaTagV2()">Copy Image Tag</button>
        </div>
    </div>
</div>

<div id="pdf-modal-v2" class="media-modal-overlay" onclick="if(event.target===this) closePdfPickerV2()">
    <div class="media-modal-box" style="max-width:520px;">
        <div class="media-modal-head">
            <h3>Insert PDF</h3>
            <button type="button" class="media-modal-close" onclick="closePdfPickerV2()">&times;</button>
        </div>
        <div style="padding:16px 20px 0;display:flex;gap:0;border-bottom:1px solid var(--border);">
            <button type="button" class="pdf-src-tab-v2 active" id="pdfTabLibraryV2" onclick="pdfShowTabV2('library')">Library</button>
            <button type="button" class="pdf-src-tab-v2" id="pdfTabUrlV2" onclick="pdfShowTabV2('url')">External URL</button>
        </div>
        <div id="pdfPaneLibraryV2" style="padding:16px 20px;max-height:320px;overflow-y:auto;">
            <div style="text-align:center;color:var(--muted);font-size:.85rem;">Loading…</div>
        </div>
        <div id="pdfPaneUrlV2" style="display:none;padding:16px 20px;">
            <label style="font-size:.75rem;color:var(--muted);display:block;margin-bottom:6px;">PDF URL</label>
            <input type="url" id="pdfExternalUrlV2" placeholder="https://example.com/document.pdf" style="width:100%;">
        </div>
        <div style="padding:0 20px 16px;">
            <label style="font-size:.75rem;color:var(--muted);display:block;margin-bottom:6px;">Caption (optional)</label>
            <input type="text" id="pdfCaptionV2" placeholder="Document title or description" style="width:100%;">
        </div>
        <div id="pdf-modal-actions-v2" class="media-modal-actions">
            <span id="pdf-modal-selected-name-v2" class="selected-name"></span>
            <button type="button" class="btn btn-sm" onclick="insertPdfV2()">Insert at Cursor</button>
        </div>
    </div>
</div>

<div id="yt-modal-v2" class="media-modal-overlay" onclick="if(event.target===this) closeYtPickerV2()">
    <div class="media-modal-box" style="max-width:520px;">
        <div class="media-modal-head">
            <h3>Insert YouTube Video</h3>
            <button type="button" class="media-modal-close" onclick="closeYtPickerV2()">&times;</button>
        </div>
        <div style="padding:16px 20px 0;display:flex;gap:0;border-bottom:1px solid var(--border);">
            <button type="button" class="pdf-src-tab-v2 active" id="ytTabLibraryV2" onclick="ytShowTabV2('library')">Saved Links</button>
            <button type="button" class="pdf-src-tab-v2" id="ytTabUrlV2" onclick="ytShowTabV2('url')">Paste URL / ID</button>
        </div>
        <div id="ytPaneLibraryV2" style="padding:16px 20px;max-height:320px;overflow-y:auto;">
            <div style="text-align:center;color:var(--muted);font-size:.85rem;">Loading…</div>
        </div>
        <div id="ytPaneUrlV2" style="display:none;padding:16px 20px;">
            <label style="font-size:.75rem;color:var(--muted);display:block;margin-bottom:6px;">YouTube URL or Video ID</label>
            <input type="url" id="ytExternalUrlV2" placeholder="https://www.youtube.com/watch?v=dQw4w9WgXcQ" style="width:100%;">
        </div>
        <div style="padding:0 20px 16px;">
            <label style="font-size:.75rem;color:var(--muted);display:block;margin-bottom:6px;">Caption (optional)</label>
            <input type="text" id="ytCaptionV2" placeholder="Video title or description" style="width:100%;">
        </div>
        <div id="yt-modal-actions-v2" class="media-modal-actions">
            <span id="yt-modal-selected-name-v2" class="selected-name"></span>
            <button type="button" class="btn btn-sm" onclick="insertYtV2()">Insert at Cursor</button>
        </div>
    </div>
</div>
</body>
</html>
"""

@app.route('/')
def main_v2():
    db.mount()
    authors = db.get_records("AuthorProfile")
    cats    = db.get_records("Category")
    pages   = db.get_records("PageRecord")
    return render_template_string(_SHELL, 
                                   categories=cats, 
                                   authors=authors, 
                                   pages=pages,
                                   default_html=DEFAULT_HTML,
                                   admin_url=f"http://localhost:{ADMIN_PORT}/")

if __name__ == "__main__":
    _legacy = [f for f in ["Flask_CMS.py", "Flask_CMS_Publisher.py", "Flask_Page_Editor.py",
                            "Flask_Profile_Manager.py", "Page_Editor_v2.py"]
               if os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), f))]
    if _legacy:
        print(f"\n    !! WARNING: old pre-rename file(s) still present: {', '.join(_legacy)} -- delete them, they are unmaintained leftovers from before the Blueprint split.\n")
    # Port resolved via config.json (pageeditorv2_port) / CMS_PAGEEDITORV2_PORT env.
    app.run(host="0.0.0.0", port=PAGEEDITORV2_PORT, debug=False)
